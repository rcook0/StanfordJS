# sjs-port skeleton

Production-lean scaffold for porting StanfordJS components:
- C++ core (Eigen) with pybind11 bindings
- Python wheels via scikit-build-core
- GoogleTest + pytest for parity
