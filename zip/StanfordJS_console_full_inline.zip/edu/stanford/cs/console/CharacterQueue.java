package edu.stanford.cs.console;
/**
 * Console subsystem component: bridges Swing events and program-facing character streams.
 * Coordinates UI thread with background work using synchronized regions and wait/notify where appropriate.
 * OS analogy: behaves like cooperative scheduler loop.
 */


class CharacterQueue {
   private String buffer = "";
   private boolean isWaiting;

   public CharacterQueue() {
   }/**
 * Implements `enqueue(char ch)` returning `void`. This method coordinates thread handoff via wait/notify. Non-trivial control flow (≈4 LOC, complexity score 2).
 */


   public synchronized void enqueue(char ch) {
      this.buffer = this.buffer + ch;
      this.notifyAll();
   }/**
 * Implements `enqueue(String str)` returning `void`. This method coordinates thread handoff via wait/notify. Non-trivial control flow (≈4 LOC, complexity score 2).
 */


   public synchronized void enqueue(String str) {
      this.buffer = this.buffer + str;
      this.notifyAll();
   }/**
 * Implements `dequeue()` returning `char`. This method coordinates thread handoff via wait/notify; wraps operations in exception handling. Non-trivial control flow (≈14 LOC, complexity score 4).
 */


   public synchronized char dequeue() {
      while(this.buffer.length() == 0) {
         try {
            this.isWaiting = true;
            this.wait();
            this.isWaiting = false;
         } catch (InterruptedException var2) {
         }
      }

      char ch = this.buffer.charAt(0);
      this.buffer = this.buffer.substring(1);
      return ch;
   }/**
 * Implements `clear()` returning `void`. This method coordinates thread handoff via wait/notify. Non-trivial control flow (≈4 LOC, complexity score 2).
 */


   public synchronized void clear() {
      this.buffer = "";
      this.notifyAll();
   }

   public boolean isWaiting() {
      return this.isWaiting;
   }
}
