package edu.stanford.cs.console;

import java.awt.Font;
import javax.swing.JFrame;
/**
 * Top-level Swing window for the Stanford console; owns the visual container and window lifecycle (open/focus/close).
 * Integrates with AWT/Swing for UI rendering, focus, scrolling, and repaint policy.
 * Inherits behavior from: JFrame implements Console.
 * Implements: Console.
 * OS analogy: behaves like display server (window + repaint).
 */


public class ConsoleWindow extends JFrame implements Console {
   public static final Font DEFAULT_FONT = Font.decode("Monospaced-12");
   public static final int DEFAULT_WIDTH = 500;
   public static final int DEFAULT_HEIGHT = 300;
   private ConsolePane cpane;

   public ConsoleWindow() {
      this(500.0D, 300.0D);
   }

   public ConsoleWindow(double width, double height) {
      super("Console Window");
      this.cpane = new ConsolePane();
      this.setFont(DEFAULT_FONT);
      this.cpane.setSize((int)Math.round(width), (int)Math.round(height));
      this.cpane.setPreferredSize(this.cpane.getSize());
      this.add(this.cpane);
      this.pack();
      this.setDefaultCloseOperation(3);
      this.setVisible(true);
   }

   public void clear() {
      this.cpane.clear();
   }

   public void print(Object value) {
      this.cpane.print(value.toString());
   }

   public void println() {
      this.cpane.print("\n");
   }/**
 * Implements `println(Object value)` returning `void`. This method writes to output buffer or display. OS analogy: TTY write path. Non-trivial control flow (≈4 LOC, complexity score 2).
 */


   public void println(Object value) {
      this.print(value);
      this.println();
   }

   public void printf(String format, Object... args) {
      this.print(String.format(format, args));
   }

   public void format(String format, Object... args) {
      System.out.printf(format, args);
   }

   public String nextLine() {
      return this.cpane.nextLine();
   }/**
 * Implements `nextLine(String prompt)` returning `String`. This method writes to output buffer or display. Non-trivial control flow (≈7 LOC, complexity score 2).
 */


   public String nextLine(String prompt) {
      if (prompt != null) {
         this.print(prompt);
      }

      return this.nextLine();
   }

   public int nextInt() {
      return this.nextInt((String)null);
   }/**
 * Implements `nextInt(String prompt)` returning `int`. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈14 LOC, complexity score 4).
 */


   public int nextInt(String prompt) {/**
 * Implements `while(true)` returning ``. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈12 LOC, complexity score 4).
 */

      while(true) {
         String line = this.nextLine(prompt);

         try {
            return Integer.parseInt(line);
         } catch (NumberFormatException var4) {
            this.println("Illegal integer format");
            if (prompt == null) {
               prompt = "Retry: ";
            }
         }
      }
   }

   public double nextDouble() {
      return this.nextDouble((String)null);
   }/**
 * Implements `nextDouble(String prompt)` returning `double`. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈14 LOC, complexity score 4).
 */


   public double nextDouble(String prompt) {/**
 * Implements `while(true)` returning ``. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈12 LOC, complexity score 4).
 */

      while(true) {
         String line = this.nextLine(prompt);

         try {
            return Double.parseDouble(line);
         } catch (NumberFormatException var4) {
            this.println("Illegal floating-point format");
            if (prompt == null) {
               prompt = "Retry: ";
            }
         }
      }
   }/**
 * Implements `setFont(Font font)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public void setFont(Font font) {
      super.setFont(font);
      if (this.cpane != null) {
         this.cpane.setFont(font);
      }

   }

   public void setFont(String str) {
      this.setFont(Font.decode(str));
   }
}
