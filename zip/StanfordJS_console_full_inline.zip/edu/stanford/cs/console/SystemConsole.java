package edu.stanford.cs.console;

import java.io.IOException;
/**
 * System stream redirector: binds System.in/out/err to the console runtime for student programs.
 * Implements: Console.
 */


public class SystemConsole implements Console {
   private int prevChar;

   public void print(Object value) {
      System.out.print(value);
   }

   public void println() {
      System.out.println();
   }

   public void println(Object value) {
      System.out.println(value);
   }

   public void printf(String format, Object... args) {
      System.out.printf(format, args);
   }

   public void format(String format, Object... args) {
      System.out.printf(format, args);
   }/**
 * Implements `nextLine()` returning `String`. This method reads from input stream or line buffer; wraps operations in exception handling. Non-trivial control flow (≈32 LOC, complexity score 7).
 */


   public String nextLine() {
      try {
         String line = "";/**
 * Implements `while(true)` returning ``. This method reads from input stream or line buffer. Non-trivial control flow (≈22 LOC, complexity score 5).
 */


         while(true) {
            int ch = System.in.read();
            if (ch == -1) {
               return null;
            }/**
 * Implements `if(ch == 13)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


            if (ch == 13) {/**
 * Implements `if(this.prevChar != 10)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.prevChar != 10) {
                  this.prevChar = ch;
                  break;
               }
            } else if (ch == 10) {/**
 * Implements `if(this.prevChar != 13)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.prevChar != 13) {
                  this.prevChar = ch;
                  break;
               }
            } else {
               line = line + (char)ch;
            }

            this.prevChar = ch;
         }

         return line;
      } catch (IOException var3) {
         throw new RuntimeException(var3.toString());
      }
   }/**
 * Implements `nextLine(String prompt)` returning `String`. This method writes to output buffer or display. Non-trivial control flow (≈7 LOC, complexity score 2).
 */


   public String nextLine(String prompt) {
      if (prompt != null) {
         this.print(prompt);
      }

      return this.nextLine();
   }

   public int nextInt() {
      return this.nextInt((String)null);
   }/**
 * Implements `nextInt(String prompt)` returning `int`. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈14 LOC, complexity score 4).
 */


   public int nextInt(String prompt) {/**
 * Implements `while(true)` returning ``. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈12 LOC, complexity score 4).
 */

      while(true) {
         String line = this.nextLine(prompt);

         try {
            return Integer.parseInt(line);
         } catch (NumberFormatException var4) {
            this.println("Illegal integer format");
            if (prompt == null) {
               prompt = "Retry: ";
            }
         }
      }
   }

   public double nextDouble() {
      return this.nextDouble((String)null);
   }/**
 * Implements `nextDouble(String prompt)` returning `double`. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈14 LOC, complexity score 4).
 */


   public double nextDouble(String prompt) {/**
 * Implements `while(true)` returning ``. This method writes to output buffer or display; wraps operations in exception handling. Non-trivial control flow (≈12 LOC, complexity score 4).
 */

      while(true) {
         String line = this.nextLine(prompt);

         try {
            return Double.parseDouble(line);
         } catch (NumberFormatException var4) {
            this.println("Illegal floating-point format");
            if (prompt == null) {
               prompt = "Retry: ";
            }
         }
      }
   }
}
