package edu.stanford.cs.controller;

import java.awt.Adjustable;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
/**
 * Speed/timing listener adjusting pacing of the controller loop based on user input or program state.
 * Implements: AdjustmentListener.
 * OS analogy: behaves like cooperative scheduler loop.
 */


class SpeedListener implements AdjustmentListener {
   private Controller controller;

   public SpeedListener(Controller controller) {
      this.controller = controller;
   }

   public void adjustmentValueChanged(AdjustmentEvent e) {
      this.controller.setSpeedCallback(((Adjustable)e.getSource()).getValue());
   }
}
