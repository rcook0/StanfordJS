package edu.stanford.cs.controller;
/**
 * Contract for components that advance via discrete step() calls orchestrated by a controller.
 * Targets objects implementing Steppable to deliver deterministic step() ticks.
 * OS analogy: behaves like cooperative scheduler loop.
 */


public interface Steppable {
   void step();

   boolean isCallable();

   int getStackDepth();
}
