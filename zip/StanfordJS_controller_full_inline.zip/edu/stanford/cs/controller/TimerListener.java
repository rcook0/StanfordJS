package edu.stanford.cs.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * Controller subsystem component participating in scheduling and event-loop orchestration.
 * Handles timing/interval computations to hit a target rate or delay between steps.
 * Observes UI or program events to pause/resume or adjust speed in response to signals.
 * Implements: ActionListener.
 * OS analogy: behaves like cooperative scheduler loop.
 */


class TimerListener implements ActionListener {
   private Controller controller;

   public TimerListener(Controller controller) {
      this.controller = controller;
   }

   public void actionPerformed(ActionEvent e) {
      this.controller.executeTimeStep();
   }
}
