package edu.stanford.cs.controller;
/**
 * Controller subsystem component participating in scheduling and event-loop orchestration.
 * OS analogy: behaves like cooperative scheduler loop.
 */


public interface Updatable {
   void update();

   void setUpdater(Updater var1);

   void setEnabled(boolean var1);
}
