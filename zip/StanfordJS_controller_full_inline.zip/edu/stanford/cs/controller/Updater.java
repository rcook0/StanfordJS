package edu.stanford.cs.controller;
/**
 * Controller subsystem component participating in scheduling and event-loop orchestration.
 * OS analogy: behaves like cooperative scheduler loop.
 */


public interface Updater {
   void update(Updatable var1);
}
