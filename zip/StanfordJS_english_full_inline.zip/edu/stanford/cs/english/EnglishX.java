package edu.stanford.cs.english;
/**
 * Package component providing functionality within this subsystem.
 */


class EnglishX {
   static final String[] WORDS = new String[]{"xanthate", "xanthates", "xanthein", "xantheins", "xanthene", "xanthenes", "xanthic", "xanthin", "xanthine", "xanthines", "xanthins", "xanthoma", "xanthomas", "xanthomata", "xanthone", "xanthones", "xanthous", "xebec", "xebecs", "xenia", "xenial", "xenias", "xenic", "xenogamies", "xenogamy", "xenogenies", "xenogeny", "xenolith", "xenolithic", "xenoliths", "xenon", "xenons", "xenophobe", "xenophobes", "xenophobia", "xenophobic", "xerarch", "xeric", "xerographic", "xerographically", "xerographies", "xerography", "xerophyte", "xerophytes", "xerophytic", "xerosere", "xeroseres", "xeroses", "xerosis", "xerotic", "xerus", "xeruses", "xi", "xiphoid", "xiphoids", "xis", "xu", "xylan", "xylans", "xylem", "xylems", "xylene", "xylenes", "xylidin", "xylidine", "xylidines", "xylidins", "xylocarp", "xylocarps", "xyloid", "xylol", "xylols", "xylophone", "xylophones", "xylophonist", "xylophonists", "xylose", "xyloses", "xylotomies", "xylotomy", "xylyl", "xylyls", "xyst", "xyster", "xysters", "xysti", "xystoi", "xystos", "xysts", "xystus"};
}
