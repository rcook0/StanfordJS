package edu.stanford.cs.graphics;
/**
 * Package component providing functionality within this subsystem.
 */


class BMPImageSaver extends ImageSaver {
   public BMPImageSaver() {
      super("BMP", 1);
   }
}
