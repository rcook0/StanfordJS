package edu.stanford.cs.graphics;

import java.awt.Image;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class EPSImageSaver extends ImageSaver {
   public void saveImage(Image image) {
      throw new RuntimeException("saveImage: Not yet implemented");
   }
}
