package edu.stanford.cs.graphics;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.event.MouseEvent;
import java.util.Iterator;
import javax.swing.JComponent;
/**
 * View component managing paint/repaint cycles and user interaction.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class GCanvas extends JComponent implements GContainer, Iterable<GObject> {
   public static final int DEFAULT_WIDTH = 500;
   public static final int DEFAULT_HEIGHT = 300;
   private GCanvasListener gCanvasListener;
   private GObject lastObject;
   private GObject dragObject;
   private GObjectList contents;
   private boolean autoRepaint;
   private boolean nativeArcFlag;

   public GCanvas() {
      this(500.0D, 300.0D);
   }

   public GCanvas(double width, double height) {
      this.contents = new GObjectList(this);
      this.setBackground(Color.WHITE);
      this.setForeground(Color.BLACK);
      this.setOpaque(true);
      this.setAutoRepaintFlag(true);
      this.setNativeArcFlag(false);
      this.setLayout((LayoutManager)null);
      this.gCanvasListener = new GCanvasListener(this);
      this.addMouseListener(this.gCanvasListener);
      this.addMouseMotionListener(this.gCanvasListener);
      Dimension size = new Dimension(GMath.round(width), GMath.round(height));
      this.setPreferredSize(size);
      this.setSize(size);
   }

   public void clear() {
      this.removeAll();
   }/**
 * Implements `removeAll()` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void removeAll() {
      this.contents.removeAll();
      this.conditionalRepaint();
   }/**
 * Implements `add(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void add(GObject gobj) {
      this.contents.add(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `add(GObject gobj, double x, double y)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public final void add(GObject gobj, double x, double y) {
      gobj.setLocation(x, y);
      this.add(gobj);
   }

   public final void add(GObject gobj, GPoint pt) {
      this.add(gobj, pt.getX(), pt.getY());
   }/**
 * Implements `remove(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void remove(GObject gobj) {
      this.contents.remove(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `add(Component comp)` returning `Component`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈18 LOC, complexity score 3).
 */


   public Component add(Component comp) {
      super.add(comp);
      Dimension size = comp.getSize();/**
 * Implements `if(size.width == 0 || size.height == 0)` returning ``. Non-trivial control flow (≈12 LOC, complexity score 2).
 */

      if (size.width == 0 || size.height == 0) {
         Dimension preferredSize = comp.getPreferredSize();
         if (size.width == 0) {
            size.width = preferredSize.width;
         }

         if (size.height == 0) {
            size.height = preferredSize.height;
         }

         comp.setSize(size);
      }

      return comp;
   }/**
 * Implements `add(Component comp, double x, double y)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public final void add(Component comp, double x, double y) {
      comp.setLocation(GMath.round(x), GMath.round(y));
      this.add(comp);
   }

   public final void add(Component comp, GPoint pt) {
      this.add(comp, pt.getX(), pt.getY());
   }/**
 * Implements `remove(Component comp)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void remove(Component comp) {
      super.remove(comp);
      this.conditionalRepaint();
   }

   public int getElementCount() {
      return this.contents.getElementCount();
   }

   public GObject getElement(int index) {
      return this.contents.getElement(index);
   }

   public GObject getElementAt(double x, double y) {
      return this.contents.getElementAt(x, y, false);
   }

   public final GObject getElementAt(GPoint pt) {
      return this.getElementAt(pt.getX(), pt.getY());
   }

   public final void setPreferredSize(double width, double height) {
      this.setPreferredSize(new Dimension(GMath.round(width), GMath.round(height)));
   }

   public Iterator<GObject> iterator() {
      return new GIterator(this, 0);
   }

   public Iterator<GObject> iterator(int direction) {
      return new GIterator(this, direction);
   }/**
 * Implements `paint(Graphics g)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */


   public void paint(Graphics g) {
      if (this.isOpaque()) {
         g.setColor(this.getBackground());
         g.fillRect(0, 0, this.getWidth(), this.getHeight());
         g.setColor(this.getForeground());
      }

      super.paint(g);
   }/**
 * Implements `paintComponent(Graphics g)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void paintComponent(Graphics g) {
      this.contents.mapPaint(g);
      super.paintComponent(g);
   }

   public void setAutoRepaintFlag(boolean state) {
      this.autoRepaint = state;
   }

   public boolean getAutoRepaintFlag() {
      return this.autoRepaint;
   }

   public void setNativeArcFlag(boolean state) {
      this.nativeArcFlag = state;
   }

   public boolean getNativeArcFlag() {
      return this.nativeArcFlag;
   }/**
 * Implements `sendToFront(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendToFront(GObject gobj) {
      this.contents.sendToFront(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `sendToBack(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendToBack(GObject gobj) {
      this.contents.sendToBack(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `sendForward(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendForward(GObject gobj) {
      this.contents.sendForward(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `sendBackward(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendBackward(GObject gobj) {
      this.contents.sendBackward(gobj);
      this.conditionalRepaint();
   }/**
 * Implements `dispatchMouseEvent(MouseEvent e)` returning `void`. Non-trivial control flow (≈39 LOC, complexity score 9).
 */


   protected void dispatchMouseEvent(MouseEvent e) {
      GObject gobj = this.contents.getElementAt((double)e.getX(), (double)e.getY(), true);
      MouseEvent newEvent = null;/**
 * Implements `if(gobj != this.lastObject)` returning ``. Non-trivial control flow (≈11 LOC, complexity score 2).
 */

      if (gobj != this.lastObject) {/**
 * Implements `if(this.lastObject != null)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (this.lastObject != null) {
            newEvent = new GMouseEvent(this.lastObject, 505, e);
            this.lastObject.fireMouseListeners(newEvent);
         }/**
 * Implements `if(gobj != null)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


         if (gobj != null) {
            newEvent = new GMouseEvent(gobj, 504, e);
            gobj.fireMouseListeners(newEvent);
         }
      }

      this.lastObject = gobj;
      if (this.dragObject != null) {
         gobj = this.dragObject;
      }/**
 * Implements `if(gobj != null)` returning ``. Non-trivial control flow (≈13 LOC, complexity score 3).
 */


      if (gobj != null) {
         int id = e.getID();
         if (id != 505 && id != 504 && (id != 506 || this.dragObject != null)) {
            if (id == 501) {
               this.dragObject = gobj;
            } else if (id == 502) {
               this.dragObject = null;
            }

            newEvent = new GMouseEvent(gobj, id, e);
            gobj.fireMouseListeners(newEvent);
         }
      }

      if (newEvent != null && newEvent.isConsumed()) {
         e.consume();
      }

   }/**
 * Implements `conditionalRepaint()` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


   protected void conditionalRepaint() {
      if (this.autoRepaint) {
         this.repaint();
      }

   }

   protected void updateEnabledList() {
      this.contents.updateEnabledList();
   }

   static MouseEvent createMouseEvent(Object gobj, int eventID, MouseEvent e) {
      return new GMouseEvent(gobj, eventID, e);
   }
}
