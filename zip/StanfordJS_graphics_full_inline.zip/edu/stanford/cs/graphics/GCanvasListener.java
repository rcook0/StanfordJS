package edu.stanford.cs.graphics;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
/**
 * View component managing paint/repaint cycles and user interaction.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class GCanvasListener implements MouseListener, MouseMotionListener {
   private GCanvas gCanvas;

   public GCanvasListener(GCanvas gc) {
      this.gCanvas = gc;
   }

   public void mouseClicked(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }/**
 * Implements `mousePressed(MouseEvent e)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void mousePressed(MouseEvent e) {
      this.gCanvas.requestFocus();
      this.gCanvas.dispatchMouseEvent(e);
   }

   public void mouseReleased(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }

   public void mouseEntered(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }

   public void mouseExited(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }

   public void mouseDragged(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }

   public void mouseMoved(MouseEvent e) {
      this.gCanvas.dispatchMouseEvent(e);
   }
}
