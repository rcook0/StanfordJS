package edu.stanford.cs.graphics;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.util.Iterator;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 */


public class GCompound extends GObject implements GContainer, Iterable<GObject> {
   private GObjectList contents = new GObjectList(this);
   private transient GObject lastObject;
   private transient GObject dragObject;/**
 * Implements `add(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void add(GObject gobj) {
      this.contents.add(gobj);
      this.repaint();
   }/**
 * Implements `add(GObject gobj, double x, double y)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public final void add(GObject gobj, double x, double y) {
      gobj.setLocation(x, y);
      this.add(gobj);
   }

   public final void add(GObject gobj, GPoint pt) {
      this.add(gobj, pt.getX(), pt.getY());
   }/**
 * Implements `remove(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void remove(GObject gobj) {
      this.contents.remove(gobj);
      this.repaint();
   }/**
 * Implements `removeAll()` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void removeAll() {
      this.contents.removeAll();
      this.repaint();
   }

   public int getElementCount() {
      return this.contents.getElementCount();
   }

   public GObject getElement(int index) {
      return this.contents.getElement(index);
   }

   public GObject getElementAt(double x, double y) {
      return this.contents.getElementAt(x, y, false);
   }

   public final GObject getElementAt(GPoint pt) {
      return this.getElementAt(pt.getX(), pt.getY());
   }

   public Iterator<GObject> iterator() {
      return new GIterator(this, 0);
   }

   public Iterator<GObject> iterator(int direction) {
      return new GIterator(this, direction);
   }/**
 * Implements `clone()` returning `Object`. Non-trivial control flow (≈9 LOC, complexity score 2).
 */


   public Object clone() {
      try {
         GCompound clone = (GCompound)super.clone();
         clone.contents = new GObjectList(clone, this.contents);
         return clone;
      } catch (Exception var2) {
         throw new RuntimeException("Impossible exception");
      }
   }

   public final GPoint getCanvasPoint(GPoint localPoint) {
      return this.getCanvasPoint(localPoint.getX(), localPoint.getY());
   }/**
 * Implements `getCanvasPoint(double x, double y)` returning `GPoint`. Non-trivial control flow (≈10 LOC, complexity score 0).
 */


   public GPoint getCanvasPoint(double x, double y) {
      GCompound comp;
      for(Object c = this; c instanceof GCompound; c = comp.getParent()) {
         comp = (GCompound)c;
         x += comp.getX();
         y += comp.getY();
      }

      return new GPoint(x, y);
   }

   public final GPoint getLocalPoint(GPoint canvasPoint) {
      return this.getLocalPoint(canvasPoint.getX(), canvasPoint.getY());
   }/**
 * Implements `getLocalPoint(double x, double y)` returning `GPoint`. Non-trivial control flow (≈10 LOC, complexity score 0).
 */


   public GPoint getLocalPoint(double x, double y) {
      GCompound comp;
      for(Object c = this; c instanceof GCompound; c = comp.getParent()) {
         comp = (GCompound)c;
         x -= comp.getX();
         y -= comp.getY();
      }

      return new GPoint(x, y);
   }/**
 * Implements `localBounds(GTransform ctm)` returning `GRectangle`. This method guards state changes with synchronized blocks; manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈21 LOC, complexity score 1).
 */


   protected GRectangle localBounds(GTransform ctm) {
      GRectangle bb = new GRectangle();/**
 * Implements `synchronized(this.contents)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈18 LOC, complexity score 1).
 */

      synchronized(this.contents) {
         int n = this.contents.getElementCount();/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈12 LOC, complexity score 1).
 */


         for(int i = 0; i < n; ++i) {
            GObject obj = this.contents.getElement(i);
            GTransform t = new GTransform(ctm);
            t.translate(obj.getX(), obj.getY());
            t.concatenate(obj.getCTM());
            GRectangle r = obj.localBounds(t);
            if (i == 0) {
               bb = r;
            } else {
               bb.add(r);
            }
         }

         return bb;
      }
   }/**
 * Implements `localContains(double x, double y)` returning `boolean`. This method guards state changes with synchronized blocks. Non-trivial control flow (≈13 LOC, complexity score 1).
 */


   protected boolean localContains(double x, double y) {/**
 * Implements `synchronized(this.contents)` returning ``. Non-trivial control flow (≈11 LOC, complexity score 1).
 */

      synchronized(this.contents) {
         int n = this.contents.getElementCount();/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 1).
 */


         for(int i = 0; i < n; ++i) {
            if (this.contents.getElement(i).contains(x, y)) {
               return true;
            }
         }

         return false;
      }
   }

   protected void paint2d(Graphics2D g) {
      this.contents.mapPaint(g);
   }/**
 * Implements `sendToFront(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendToFront(GObject gobj) {
      this.contents.sendToFront(gobj);
      this.repaint();
   }/**
 * Implements `sendToBack(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendToBack(GObject gobj) {
      this.contents.sendToBack(gobj);
      this.repaint();
   }/**
 * Implements `sendForward(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendForward(GObject gobj) {
      this.contents.sendForward(gobj);
      this.repaint();
   }/**
 * Implements `sendBackward(GObject gobj)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void sendBackward(GObject gobj) {
      this.contents.sendBackward(gobj);
      this.repaint();
   }/**
 * Implements `fireMouseListeners(MouseEvent e)` returning `void`. Non-trivial control flow (≈44 LOC, complexity score 10).
 */


   protected void fireMouseListeners(MouseEvent e) {
      if (super.areMouseListenersEnabled()) {
         super.fireMouseListeners(e);
      } else {
         GPoint pt = new GPoint((double)e.getX() - this.getX(), (double)e.getY() - this.getY());
         GObject gobj = this.getElementAt(pt);
         MouseEvent newEvent = null;/**
 * Implements `if(gobj != this.lastObject)` returning ``. Non-trivial control flow (≈11 LOC, complexity score 2).
 */

         if (gobj != this.lastObject) {/**
 * Implements `if(this.lastObject != null)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

            if (this.lastObject != null) {
               newEvent = GCanvas.createMouseEvent(this.lastObject, 505, e);
               this.lastObject.fireMouseListeners(newEvent);
            }/**
 * Implements `if(gobj != null)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


            if (gobj != null) {
               newEvent = GCanvas.createMouseEvent(gobj, 504, e);
               gobj.fireMouseListeners(newEvent);
            }
         }

         this.lastObject = gobj;
         if (this.dragObject != null) {
            gobj = this.dragObject;
         }/**
 * Implements `if(gobj != null)` returning ``. Non-trivial control flow (≈13 LOC, complexity score 3).
 */


         if (gobj != null) {
            int id = e.getID();/**
 * Implements `if(id != 505 && id != 504)` returning ``. Non-trivial control flow (≈10 LOC, complexity score 2).
 */

            if (id != 505 && id != 504) {
               if (id == 501) {
                  this.dragObject = gobj;
               } else if (id == 502) {
                  this.dragObject = null;
               }

               newEvent = GCanvas.createMouseEvent(gobj, id, e);
               gobj.fireMouseListeners(newEvent);
            }
         }

         if (newEvent != null && newEvent.isConsumed()) {
            e.consume();
         }

      }
   }

   protected boolean areMouseListenersEnabled() {
      return super.areMouseListenersEnabled() ? true : this.contents.areMouseListenersEnabled();
   }
}
