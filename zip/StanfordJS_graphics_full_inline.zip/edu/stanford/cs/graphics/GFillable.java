package edu.stanford.cs.graphics;

import java.awt.Color;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public interface GFillable {
   void setFilled(boolean var1);

   boolean isFilled();

   void setFillColor(Color var1);

   Color getFillColor();
}
