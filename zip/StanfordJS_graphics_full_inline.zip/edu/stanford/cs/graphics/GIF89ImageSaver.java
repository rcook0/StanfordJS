package edu.stanford.cs.graphics;

import java.awt.Image;
import java.io.IOException;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class GIF89ImageSaver extends ImageSaver {/**
 * Implements `saveImage(Image image)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 2).
 */

   public void saveImage(Image image) {
      try {
         Gif89Encoder encoder = new Gif89Encoder(image);
         encoder.setTransparentIndex(0);
         encoder.getFrameAt(0).setInterlaced(true);
         encoder.encode(this.getOutputStream());
      } catch (IOException var3) {
         throw new RuntimeException("saveImage: " + var3.getMessage());
      }
   }
}
