package edu.stanford.cs.graphics;

import java.awt.Image;
import javax.imageio.ImageIO;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class GIFImageSaver extends ImageSaver {
   private GIF89ImageSaver gif89Saver;

   public GIFImageSaver() {
      super("GIF", 2);
      if (!ImageIO.getImageWritersBySuffix("gif").hasNext()) {
         this.gif89Saver = new GIF89ImageSaver();
      }

   }/**
 * Implements `saveImage(Image image)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */


   public void saveImage(Image image) {/**
 * Implements `if(this.gif89Saver != null)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (this.gif89Saver != null) {
         this.gif89Saver.setOutputStream(this.getOutputStream());
         this.gif89Saver.saveImage(image);
      } else {
         super.saveImage(image);
      }

   }
}
