package edu.stanford.cs.graphics;

import java.awt.Component;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class GLabel extends GObject {
   public static final Font DEFAULT_FONT = new Font("Default", 0, 12);
   private String label;
   private Font labelFont;
   private static final Component DUMMY_COMPONENT = GImageTools.getImageObserver();

   public GLabel(String str) {
      this(str, 0.0D, 0.0D);
   }

   public GLabel(String str, double x, double y) {
      this.label = str;
      this.setFont(DEFAULT_FONT);
      this.setLocation(x, y);
   }/**
 * Implements `setFont(Font font)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setFont(Font font) {
      this.labelFont = font;
      this.repaint();
   }

   public void setFont(String str) {
      this.setFont(Font.decode(str));
   }

   public Font getFont() {
      return this.labelFont;
   }/**
 * Implements `setLabel(String str)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setLabel(String str) {
      this.label = str;
      this.repaint();
   }

   public String getLabel() {
      return this.label;
   }/**
 * Implements `paint2d(Graphics2D g)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   protected void paint2d(Graphics2D g) {
      g.setFont(this.labelFont);
      g.drawString(this.label, 0, 0);
   }

   public double getAscent() {
      return (double)this.getFontMetrics().getAscent();
   }

   public double getDescent() {
      return (double)this.getFontMetrics().getDescent();
   }/**
 * Implements `getFontMetrics()` returning `FontMetrics`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public FontMetrics getFontMetrics() {
      Component comp = this.getComponent();
      if (comp == null) {
         comp = DUMMY_COMPONENT;
      }

      return comp.getFontMetrics(this.labelFont);
   }

   public String paramString() {
      return super.paramString() + ", string=\"" + this.label + "\"";
   }/**
 * Implements `localBounds(GTransform ctm)` returning `GRectangle`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈11 LOC, complexity score 0).
 */


   protected GRectangle localBounds(GTransform ctm) {
      FontMetrics fm = this.getFontMetrics();
      double y0 = (double)(-fm.getAscent());
      double width = (double)fm.stringWidth(this.label);
      double height = (double)fm.getHeight();
      GRectangle bb = new GRectangle(ctm.transform(0.0D, y0));
      bb.add(ctm.transform(width, y0));
      bb.add(ctm.transform(0.0D, y0 + height));
      bb.add(ctm.transform(width, y0 + height));
      return bb;
   }/**
 * Implements `localContains(double x, double y)` returning `boolean`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   protected boolean localContains(double x, double y) {
      FontMetrics fm = this.getFontMetrics();
      double y0 = (double)(-fm.getAscent());
      double width = (double)fm.stringWidth(this.label);
      double height = (double)fm.getHeight();
      return x >= 0.0D && x < width && y >= y0 && y < y0 + height;
   }
}
