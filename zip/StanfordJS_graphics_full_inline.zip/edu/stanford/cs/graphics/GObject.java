package edu.stanford.cs.graphics;

import java.awt.AWTEventMulticaster;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.lang.reflect.Method;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public abstract class GObject implements Cloneable, GScalable {
   private GCompound compoundParent;
   private GTransform ctm = new GTransform();
   private GTransform itm = null;
   private Color objectColor;
   private double lineWidth = 1.0D;
   private double x;
   private double y;
   private boolean transformed = false;
   private boolean isVisible = true;
   private boolean mouseListenersEnabled = false;
   private transient MouseListener mouseListener;
   private transient MouseMotionListener mouseMotionListener;
   private transient ActionListener actionListener;
   private transient GContainer transientParent;

   protected GObject() {
   }/**
 * Implements `paint(Graphics g)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void paint(Graphics g) {/**
 * Implements `if(this.isVisible)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

      if (this.isVisible) {
         Graphics2D g2d = this.createTransformedGraphics(g);
         this.paint2d(g2d);
         g2d.dispose();
      }

   }/**
 * Implements `getBounds()` returning `GRectangle`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public GRectangle getBounds() {
      GRectangle r = this.localBounds(this.ctm);
      r.translate(this.x, this.y);
      return r;
   }/**
 * Implements `setLocation(double x, double y)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public void setLocation(double x, double y) {
      this.x = x;
      this.y = y;
      this.repaint();
   }

   public final void setLocation(GPoint pt) {
      this.setLocation(pt.getX(), pt.getY());
   }

   public GPoint getLocation() {
      return new GPoint(this.x, this.y);
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public void move(double dx, double dy) {
      this.setLocation(this.x + dx, this.y + dy);
   }/**
 * Implements `movePolar(double r, double theta)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public final void movePolar(double r, double theta) {
      double radians = theta * 3.141592653589793D / 180.0D;
      this.move(r * Math.cos(radians), -r * Math.sin(radians));
   }/**
 * Implements `getSize()` returning `GDimension`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public GDimension getSize() {
      GRectangle bounds = this.getBounds();
      return new GDimension(bounds.getWidth(), bounds.getHeight());
   }

   public double getWidth() {
      return this.getBounds().getWidth();
   }

   public double getHeight() {
      return this.getBounds().getHeight();
   }/**
 * Implements `contains(double x, double y)` returning `boolean`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   public boolean contains(double x, double y) {
      GTransform t = new GTransform();
      t.translate(this.x, this.y);
      t.concatenate(this.getCTM());
      GPoint pt = t.inverseTransform(x, y);
      return this.localContains(pt.getX(), pt.getY());
   }

   public boolean contains(GPoint pt) {
      return this.contains(pt.getX(), pt.getY());
   }/**
 * Implements `sendToFront()` returning `void`. Non-trivial control flow (≈23 LOC, complexity score 7).
 */


   public void sendToFront() {
      if (this.compoundParent != null) {
         this.compoundParent.sendToFront(this);
      } else if (this.transientParent instanceof GCanvas) {
         ((GCanvas)this.transientParent).sendToFront(this);
      } else if (this.transientParent != null) {
         try {
            Class<?> parentClass = this.transientParent.getClass();
            Class[] types = new Class[]{Class.forName("acm.graphics.GObject")};
            Object[] args = new Object[]{this};
            Method fn = parentClass.getMethod("sendToFront", types);
            if (fn != null) {
               fn.invoke(this.transientParent, args);
            }
         } catch (Exception var5) {
         }
      }

      if (this.mouseListenersEnabled) {
         this.updateEnabledList();
      }

   }/**
 * Implements `sendToBack()` returning `void`. Non-trivial control flow (≈23 LOC, complexity score 7).
 */


   public void sendToBack() {
      if (this.compoundParent != null) {
         this.compoundParent.sendToBack(this);
      } else if (this.transientParent instanceof GCanvas) {
         ((GCanvas)this.transientParent).sendToBack(this);
      } else if (this.transientParent != null) {
         try {
            Class<?> parentClass = this.transientParent.getClass();
            Class[] types = new Class[]{Class.forName("acm.graphics.GObject")};
            Object[] args = new Object[]{this};
            Method fn = parentClass.getMethod("sendToBack", types);
            if (fn != null) {
               fn.invoke(this.transientParent, args);
            }
         } catch (Exception var5) {
         }
      }

      if (this.mouseListenersEnabled) {
         this.updateEnabledList();
      }

   }/**
 * Implements `sendForward()` returning `void`. Non-trivial control flow (≈23 LOC, complexity score 7).
 */


   public void sendForward() {
      if (this.compoundParent != null) {
         this.compoundParent.sendForward(this);
      } else if (this.transientParent instanceof GCanvas) {
         ((GCanvas)this.transientParent).sendForward(this);
      } else if (this.transientParent != null) {
         try {
            Class<?> parentClass = this.transientParent.getClass();
            Class[] types = new Class[]{Class.forName("acm.graphics.GObject")};
            Object[] args = new Object[]{this};
            Method fn = parentClass.getMethod("sendForward", types);
            if (fn != null) {
               fn.invoke(this.transientParent, args);
            }
         } catch (Exception var5) {
         }
      }

      if (this.mouseListenersEnabled) {
         this.updateEnabledList();
      }

   }/**
 * Implements `sendBackward()` returning `void`. Non-trivial control flow (≈23 LOC, complexity score 7).
 */


   public void sendBackward() {
      if (this.compoundParent != null) {
         this.compoundParent.sendBackward(this);
      } else if (this.transientParent instanceof GCanvas) {
         ((GCanvas)this.transientParent).sendBackward(this);
      } else if (this.transientParent != null) {
         try {
            Class<?> parentClass = this.transientParent.getClass();
            Class[] types = new Class[]{Class.forName("acm.graphics.GObject")};
            Object[] args = new Object[]{this};
            Method fn = parentClass.getMethod("sendBackward", types);
            if (fn != null) {
               fn.invoke(this.transientParent, args);
            }
         } catch (Exception var5) {
         }
      }

      if (this.mouseListenersEnabled) {
         this.updateEnabledList();
      }

   }/**
 * Implements `setColor(Color color)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setColor(Color color) {
      this.objectColor = color;
      this.repaint();
   }/**
 * Implements `getColor()` returning `Color`. Non-trivial control flow (≈16 LOC, complexity score 2).
 */


   public Color getColor() {
      GObject obj;
      GContainer parent;
      for(obj = this; obj.objectColor == null; obj = (GObject)parent) {
         parent = obj.getParent();
         if (!(parent instanceof GObject)) {
            if (parent instanceof Component) {
               return ((Component)parent).getForeground();
            }

            return Color.BLACK;
         }
      }

      return obj.objectColor;
   }/**
 * Implements `setLineWidth(double width)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setLineWidth(double width) {
      this.lineWidth = width;
      this.repaint();
   }

   public double getLineWidth() {
      return this.lineWidth;
   }/**
 * Implements `rotate(double theta)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void rotate(double theta) {
      this.ctm.rotate(theta);
      this.itm = null;
      this.transformed = true;
      this.repaint();
   }/**
 * Implements `scale(double sx, double sy)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void scale(double sx, double sy) {
      this.ctm.scale(sx, sy);
      this.itm = null;
      this.transformed = true;
      this.repaint();
   }

   public final void scale(double sf) {
      this.scale(sf, sf);
   }/**
 * Implements `shear(double sx, double sy)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void shear(double sx, double sy) {
      this.ctm.shear(sx, sy);
      this.itm = null;
      this.transformed = true;
      this.repaint();
   }/**
 * Implements `translate(double tx, double ty)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void translate(double tx, double ty) {
      this.ctm.translate(tx, ty);
      this.itm = null;
      this.transformed = true;
      this.repaint();
   }/**
 * Implements `setVisible(boolean visible)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setVisible(boolean visible) {
      this.isVisible = visible;
      this.repaint();
   }

   public boolean isVisible() {
      return this.isVisible;
   }/**
 * Implements `toString()` returning `String`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public String toString() {
      String name = this.getClass().getName();
      if (name.startsWith("acm.graphics.")) {
         name = name.substring("acm.graphics.".length());
      }

      return name + "[" + this.paramString() + "]";
   }

   public GContainer getParent() {
      return (GContainer)(this.compoundParent != null ? this.compoundParent : this.transientParent);
   }/**
 * Implements `addMouseListener(MouseListener listener)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public void addMouseListener(MouseListener listener) {
      this.mouseListener = AWTEventMulticaster.add(this.mouseListener, listener);
      this.mouseListenersEnabled = true;
      this.updateEnabledList();
   }

   public void removeMouseListener(MouseListener listener) {
      this.mouseListener = AWTEventMulticaster.remove(this.mouseListener, listener);
   }/**
 * Implements `addMouseMotionListener(MouseMotionListener listener)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public void addMouseMotionListener(MouseMotionListener listener) {
      this.mouseMotionListener = AWTEventMulticaster.add(this.mouseMotionListener, listener);
      this.mouseListenersEnabled = true;
      this.updateEnabledList();
   }

   public void removeMouseMotionListener(MouseMotionListener listener) {
      this.mouseMotionListener = AWTEventMulticaster.remove(this.mouseMotionListener, listener);
   }

   public void addActionListener(ActionListener listener) {
      this.actionListener = AWTEventMulticaster.add(this.actionListener, listener);
   }

   public void removeActionListener(ActionListener listener) {
      this.actionListener = AWTEventMulticaster.remove(this.actionListener, listener);
   }

   public void fireActionEvent(String actionCommand) {
      this.fireActionEvent(new ActionEvent(this, 1001, actionCommand));
   }/**
 * Implements `fireActionEvent(ActionEvent e)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


   public void fireActionEvent(ActionEvent e) {
      if (this.actionListener != null) {
         this.actionListener.actionPerformed(e);
      }

   }/**
 * Implements `clone()` returning `Object`. Non-trivial control flow (≈17 LOC, complexity score 3).
 */


   public Object clone() {
      try {
         GObject clone = (GObject)super.clone();
         clone.compoundParent = null;
         clone.transientParent = null;
         clone.mouseListener = null;
         clone.mouseMotionListener = null;
         clone.actionListener = null;
         if (clone.ctm != null) {
            clone.ctm = new GTransform(clone.ctm);
         }

         return clone;
      } catch (Exception var2) {
         throw new RuntimeException("Impossible exception");
      }
   }/**
 * Implements `setParent(GContainer parent)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void setParent(GContainer parent) {
      if (parent instanceof GCompound) {
         this.compoundParent = (GCompound)parent;
      } else {
         this.transientParent = parent;
      }

   }

   protected abstract void paint2d(Graphics2D var1);

   protected abstract GRectangle localBounds(GTransform var1);

   protected abstract boolean localContains(double var1, double var3);

   protected boolean isTransformed() {
      return this.transformed;
   }/**
 * Implements `fireMouseListeners(MouseEvent e)` returning `void`. Non-trivial control flow (≈39 LOC, complexity score 14).
 */


   protected void fireMouseListeners(MouseEvent e) {
      switch(e.getID()) {
      case 500:
         if (this.mouseListener != null) {
            this.mouseListener.mouseClicked(e);
         }
         break;
      case 501:
         if (this.mouseListener != null) {
            this.mouseListener.mousePressed(e);
         }
         break;
      case 502:
         if (this.mouseListener != null) {
            this.mouseListener.mouseReleased(e);
         }
         break;
      case 503:
         if (this.mouseMotionListener != null) {
            this.mouseMotionListener.mouseMoved(e);
         }
         break;
      case 504:
         if (this.mouseListener != null) {
            this.mouseListener.mouseEntered(e);
         }
         break;
      case 505:
         if (this.mouseListener != null) {
            this.mouseListener.mouseExited(e);
         }
         break;
      case 506:
         if (this.mouseMotionListener != null) {
            this.mouseMotionListener.mouseDragged(e);
         }
      }

   }

   protected boolean areMouseListenersEnabled() {
      return this.mouseListenersEnabled;
   }

   protected Color getObjectColor() {
      return this.objectColor;
   }

   protected GTransform getCTM() {
      return this.ctm;
   }/**
 * Implements `getITM()` returning `GTransform`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   protected GTransform getITM() {
      if (this.itm == null) {
         this.itm = this.ctm.createInverse();
      }

      return this.itm;
   }/**
 * Implements `createTransformedGraphics(Graphics g)` returning `Graphics2D`. Non-trivial control flow (≈14 LOC, complexity score 1).
 */


   protected Graphics2D createTransformedGraphics(Graphics g) {
      Graphics2D g2d = (Graphics2D)g.create();
      Color objectColor = this.getObjectColor();
      if (objectColor != null) {
         g2d.setColor(objectColor);
      }

      AffineTransform at = new AffineTransform(this.ctm.getScaleX(), this.ctm.getShearY(), this.ctm.getShearX(), this.ctm.getScaleY(), this.ctm.getTranslateX(), this.ctm.getTranslateY());
      g2d.translate(this.getX(), this.getY());
      g2d.setStroke(new BasicStroke((float)this.lineWidth));
      g2d.transform(at);
      g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
      return g2d;
   }/**
 * Implements `paramString()` returning `String`. Non-trivial control flow (≈24 LOC, complexity score 4).
 */


   protected String paramString() {
      String param = "";/**
 * Implements `if(this instanceof GResizable)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (this instanceof GResizable) {
         GRectangle r = this.getBounds();
         param = param + "bounds=(" + dts(r.getX()) + ", " + dts(r.getY()) + ", " + dts(r.getWidth()) + ", " + dts(r.getHeight()) + ")";
      } else {
         GPoint pt = this.getLocation();
         param = param + "location=(" + dts(pt.getX()) + ", " + dts(pt.getY()) + ")";
      }

      if (this.objectColor != null) {
         param = param + ", color=" + colorName(this.objectColor);
      }/**
 * Implements `if(this instanceof GFillable)` returning ``. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


      if (this instanceof GFillable) {
         param = param + ", filled=" + ((GFillable)this).isFilled();
         Color fillColor = ((GFillable)this).getFillColor();
         if (fillColor != null && fillColor != this.objectColor) {
            param = param + ", fillColor=" + colorName(fillColor);
         }
      }

      return param;
   }

   protected static String dts(double d) {
      return d == (double)((long)d) ? "" + (long)d : "" + d;
   }/**
 * Implements `colorName(Color color)` returning `String`. Non-trivial control flow (≈32 LOC, complexity score 13).
 */


   protected static String colorName(Color color) {
      if (color.equals(Color.BLACK)) {
         return "BLACK";
      } else if (color.equals(Color.BLUE)) {
         return "BLUE";
      } else if (color.equals(Color.CYAN)) {
         return "CYAN";
      } else if (color.equals(Color.DARK_GRAY)) {
         return "DARK_GRAY";
      } else if (color.equals(Color.GRAY)) {
         return "GRAY";
      } else if (color.equals(Color.GREEN)) {
         return "GREEN";
      } else if (color.equals(Color.LIGHT_GRAY)) {
         return "LIGHT_GRAY";
      } else if (color.equals(Color.MAGENTA)) {
         return "MAGENTA";
      } else if (color.equals(Color.ORANGE)) {
         return "ORANGE";
      } else if (color.equals(Color.PINK)) {
         return "PINK";
      } else if (color.equals(Color.RED)) {
         return "RED";
      } else if (color.equals(Color.WHITE)) {
         return "WHITE";
      } else if (color.equals(Color.YELLOW)) {
         return "YELLOW";
      } else {
         int rgb = color.getRGB() & 16777215;
         return "0x" + Integer.toString(rgb, 16).toUpperCase();
      }
   }/**
 * Implements `getComponent()` returning `Component`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   protected Component getComponent() {
      GContainer parent;
      for(parent = this.getParent(); parent instanceof GObject; parent = ((GObject)parent).getParent()) {
      }

      return parent instanceof Component ? (Component)parent : null;
   }/**
 * Implements `updateEnabledList()` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   protected void updateEnabledList() {
      Component comp = this.getComponent();
      if (comp instanceof GCanvas) {
         ((GCanvas)comp).updateEnabledList();
      }

   }/**
 * Implements `repaint()` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   protected void repaint() {
      GContainer parent;
      for(parent = this.getParent(); parent instanceof GObject; parent = ((GObject)parent).getParent()) {
      }

      if (parent instanceof GCanvas) {
         ((GCanvas)parent).conditionalRepaint();
      }

   }
}
