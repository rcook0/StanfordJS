package edu.stanford.cs.graphics;

import java.awt.Graphics;
import java.util.ArrayList;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 * Uses core collections for buffering, indexing, or caching.
 */


class GObjectList {
   private transient GContainer parent;
   private ArrayList<GObject> contents;
   private ArrayList<GObject> enabledList;

   public GObjectList(GContainer container) {
      this.parent = container;
      this.contents = new ArrayList();
      if (this.parent instanceof GCanvas) {
         this.enabledList = new ArrayList();
      }

   }

   public GObjectList(GContainer container, GObjectList list) {
      this.parent = container;
      this.contents = new ArrayList();
      this.enabledList = new ArrayList();
      int nElements = list.contents.size();

      for(int i = 0; i < nElements; ++i) {
         this.contents.add((GObject)((GObject)list.contents.get(i)).clone());
      }

   }/**
 * Implements `add(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈12 LOC, complexity score 2).
 */


   public synchronized void add(GObject gobj) {
      if (gobj.getParent() != null) {
         gobj.getParent().remove(gobj);
      }

      gobj.setParent(this.parent);
      this.contents.add(gobj);
      if (this.enabledList != null && gobj.areMouseListenersEnabled()) {
         this.enabledList.add(gobj);
      }

   }/**
 * Implements `remove(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public synchronized void remove(GObject gobj) {
      this.contents.remove(gobj);
      gobj.setParent((GContainer)null);
      if (this.enabledList != null) {
         this.enabledList.remove(gobj);
      }

   }/**
 * Implements `removeAll()` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public synchronized void removeAll() {
      this.contents.clear();
      if (this.enabledList != null) {
         this.enabledList.clear();
      }

   }

   public int getElementCount() {
      return this.contents.size();
   }

   public GObject getElement(int index) {
      return (GObject)this.contents.get(index);
   }/**
 * Implements `getElementAt(double x, double y, boolean requireEnabled)` returning `GObject`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈12 LOC, complexity score 1).
 */


   public synchronized GObject getElementAt(double x, double y, boolean requireEnabled) {
      ArrayList<GObject> list = requireEnabled ? this.enabledList : this.contents;

      for(int i = list.size() - 1; i >= 0; --i) {
         GObject gobj = (GObject)list.get(i);
         if (gobj.contains(x, y)) {
            return gobj;
         }
      }

      return null;
   }/**
 * Implements `sendToFront(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public synchronized void sendToFront(GObject gobj) {
      int index = this.contents.indexOf(gobj);/**
 * Implements `if(index >= 0)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (index >= 0) {
         this.contents.remove(index);
         this.contents.add(gobj);
      }

   }/**
 * Implements `sendToBack(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public synchronized void sendToBack(GObject gobj) {
      int index = this.contents.indexOf(gobj);/**
 * Implements `if(index >= 0)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (index >= 0) {
         this.contents.remove(index);
         this.contents.add(0, gobj);
      }

   }/**
 * Implements `sendForward(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public synchronized void sendForward(GObject gobj) {
      int index = this.contents.indexOf(gobj);/**
 * Implements `if(index >= 0)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (index >= 0) {
         this.contents.remove(index);
         this.contents.add(Math.min(this.contents.size(), index + 1), gobj);
      }

   }/**
 * Implements `sendBackward(GObject gobj)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public synchronized void sendBackward(GObject gobj) {
      int index = this.contents.indexOf(gobj);/**
 * Implements `if(index >= 0)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (index >= 0) {
         this.contents.remove(index);
         this.contents.add(Math.max(0, index - 1), gobj);
      }

   }/**
 * Implements `mapPaint(Graphics g)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈8 LOC, complexity score 0).
 */


   public synchronized void mapPaint(Graphics g) {
      int nElements = this.contents.size();

      for(int i = 0; i < nElements; ++i) {
         ((GObject)this.contents.get(i)).paint(g);
      }

   }/**
 * Implements `areMouseListenersEnabled()` returning `boolean`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈12 LOC, complexity score 1).
 */


   public synchronized boolean areMouseListenersEnabled() {
      int nElements = this.contents.size();/**
 * Implements `for(int i = 0; i < nElements; ++i)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈6 LOC, complexity score 1).
 */


      for(int i = 0; i < nElements; ++i) {
         GObject gobj = (GObject)this.contents.get(i);
         if (gobj.areMouseListenersEnabled()) {
            return true;
         }
      }

      return false;
   }/**
 * Implements `updateEnabledList()` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈12 LOC, complexity score 1).
 */


   public synchronized void updateEnabledList() {
      this.enabledList.clear();
      int nElements = this.contents.size();/**
 * Implements `for(int i = 0; i < nElements; ++i)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈6 LOC, complexity score 1).
 */


      for(int i = 0; i < nElements; ++i) {
         GObject gobj = (GObject)this.contents.get(i);
         if (gobj.areMouseListenersEnabled()) {
            this.enabledList.add(gobj);
         }
      }

   }
}
