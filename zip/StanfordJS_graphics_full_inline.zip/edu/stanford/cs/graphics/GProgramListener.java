package edu.stanford.cs.graphics;

import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 */


class GProgramListener implements ComponentListener, MouseListener, Runnable {
   private GWindow gw;
   private Thread mainThread;
   private boolean clickFlag;

   public GProgramListener(GWindow gw) {
      this.gw = gw;
      this.mainThread = Thread.currentThread();
      (new Thread(this)).start();
   }/**
 * Implements `waitForClick()` returning `void`. This method coordinates threads via wait/notify. Non-trivial control flow (≈11 LOC, complexity score 4).
 */


   public synchronized void waitForClick() {
      this.clickFlag = false;/**
 * Implements `while(!this.clickFlag)` returning ``. This method coordinates threads via wait/notify. Non-trivial control flow (≈6 LOC, complexity score 4).
 */


      while(!this.clickFlag) {
         try {
            this.wait();
         } catch (InterruptedException var2) {
         }
      }

   }/**
 * Implements `run()` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 2).
 */


   public void run() {
      try {
         this.mainThread.join();
      } catch (InterruptedException var2) {
      }

      this.gw.repaint();
   }

   public void componentHidden(ComponentEvent e) {
   }

   public void componentMoved(ComponentEvent e) {
   }

   public void componentResized(ComponentEvent e) {
      this.gw.repaint();
   }

   public void componentShown(ComponentEvent e) {
      this.gw.repaint();
   }

   public void mouseClicked(MouseEvent e) {
      this.signalClickOccurred();
   }

   public void mouseEntered(MouseEvent e) {
   }

   public void mouseExited(MouseEvent e) {
   }

   public void mousePressed(MouseEvent e) {
   }

   public void mouseReleased(MouseEvent e) {
   }/**
 * Implements `signalClickOccurred()` returning `void`. This method coordinates threads via wait/notify. Non-trivial control flow (≈4 LOC, complexity score 2).
 */


   private synchronized void signalClickOccurred() {
      this.clickFlag = true;
      this.notifyAll();
   }
}
