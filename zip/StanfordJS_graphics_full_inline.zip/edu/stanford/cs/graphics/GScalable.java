package edu.stanford.cs.graphics;
/**
 * Package component providing functionality within this subsystem.
 */


public interface GScalable {
   void scale(double var1, double var3);

   void scale(double var1);
}
