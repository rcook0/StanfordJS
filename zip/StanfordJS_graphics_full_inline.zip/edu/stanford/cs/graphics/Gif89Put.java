package edu.stanford.cs.graphics;

import java.io.IOException;
import java.io.OutputStream;
/**
 * Package component providing functionality within this subsystem.
 * Handles character/byte streams with buffered I/O where needed.
 */


final class Gif89Put {/**
 * Implements `ascii(String s, OutputStream os)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈9 LOC, complexity score 0).
 */

   static void ascii(String s, OutputStream os) throws IOException {
      byte[] bytes = new byte[s.length()];

      for(int i = 0; i < bytes.length; ++i) {
         bytes[i] = (byte)s.charAt(i);
      }

      os.write(bytes);
   }/**
 * Implements `leShort(int i16, OutputStream os)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   static void leShort(int i16, OutputStream os) throws IOException {
      os.write(i16 & 255);
      os.write(i16 >> 8 & 255);
   }
}
