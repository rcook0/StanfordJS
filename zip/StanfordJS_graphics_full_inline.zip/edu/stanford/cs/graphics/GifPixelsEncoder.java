package edu.stanford.cs.graphics;

import java.io.IOException;
import java.io.OutputStream;
/**
 * Package component providing functionality within this subsystem.
 * Handles character/byte streams with buffered I/O where needed.
 */


class GifPixelsEncoder {
   private static final int EOF = -1;
   private int imgW;
   private int imgH;
   private byte[] pixAry;
   private boolean wantInterlaced;
   private int initCodeSize;
   private int countDown;
   private int xCur;
   private int yCur;
   private int curPass;
   static final int BITS = 12;
   static final int HSIZE = 5003;
   int n_bits;
   int maxbits = 12;
   int maxcode;
   int maxmaxcode = 4096;
   int[] htab = new int[5003];
   int[] codetab = new int[5003];
   int hsize = 5003;
   int free_ent = 0;
   boolean clear_flg = false;
   int g_init_bits;
   int ClearCode;
   int EOFCode;
   int cur_accum = 0;
   int cur_bits = 0;
   int[] masks = new int[]{0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 32767, 65535};
   int a_count;
   byte[] accum = new byte[256];

   GifPixelsEncoder(int width, int height, byte[] pixels, boolean interlaced, int color_depth) {
      this.imgW = width;
      this.imgH = height;
      this.pixAry = pixels;
      this.wantInterlaced = interlaced;
      this.initCodeSize = Math.max(2, color_depth);
   }/**
 * Implements `encode(OutputStream os)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   void encode(OutputStream os) throws IOException {
      os.write(this.initCodeSize);
      this.countDown = this.imgW * this.imgH;
      this.xCur = this.yCur = this.curPass = 0;
      this.compress(this.initCodeSize + 1, os);
      os.write(0);
   }/**
 * Implements `bumpPosition()` returning `void`. Non-trivial control flow (≈36 LOC, complexity score 9).
 */


   private void bumpPosition() {
      ++this.xCur;/**
 * Implements `if(this.xCur == this.imgW)` returning ``. Non-trivial control flow (≈32 LOC, complexity score 8).
 */

      if (this.xCur == this.imgW) {
         this.xCur = 0;
         if (!this.wantInterlaced) {
            ++this.yCur;
         } else {/**
 * Implements `switch(this.curPass)` returning ``. Non-trivial control flow (≈25 LOC, complexity score 7).
 */

            switch(this.curPass) {
            case 0:
               this.yCur += 8;/**
 * Implements `if(this.yCur >= this.imgH)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.yCur >= this.imgH) {
                  ++this.curPass;
                  this.yCur = 4;
               }
               break;
            case 1:
               this.yCur += 8;/**
 * Implements `if(this.yCur >= this.imgH)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.yCur >= this.imgH) {
                  ++this.curPass;
                  this.yCur = 2;
               }
               break;
            case 2:
               this.yCur += 4;/**
 * Implements `if(this.yCur >= this.imgH)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.yCur >= this.imgH) {
                  ++this.curPass;
                  this.yCur = 1;
               }
               break;
            case 3:
               this.yCur += 2;
            }
         }
      }

   }/**
 * Implements `nextPixel()` returning `int`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   private int nextPixel() {
      if (this.countDown == 0) {
         return -1;
      } else {
         --this.countDown;
         byte pix = this.pixAry[this.yCur * this.imgW + this.xCur];
         this.bumpPosition();
         return pix & 255;
      }
   }

   final int MAXCODE(int n_bits) {
      return (1 << n_bits) - 1;
   }/**
 * Implements `compress(int init_bits, OutputStream outs)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈65 LOC, complexity score 6).
 */


   void compress(int init_bits, OutputStream outs) throws IOException {
      this.g_init_bits = init_bits;
      this.clear_flg = false;
      this.n_bits = this.g_init_bits;
      this.maxcode = this.MAXCODE(this.n_bits);
      this.ClearCode = 1 << init_bits - 1;
      this.EOFCode = this.ClearCode + 1;
      this.free_ent = this.ClearCode + 2;
      this.char_init();
      int ent = this.nextPixel();
      int hshift = 0;

      int fcode;
      for(fcode = this.hsize; fcode < 65536; fcode *= 2) {
         ++hshift;
      }

      hshift = 8 - hshift;
      int hsize_reg = this.hsize;
      this.cl_hash(hsize_reg);
      this.output(this.ClearCode, outs);/**
 * Implements `while(true)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈42 LOC, complexity score 6).
 */


      while(true) {
         int c;
         label40:
         while((c = this.nextPixel()) != -1) {
            fcode = (c << this.maxbits) + ent;
            int i = c << hshift ^ ent;
            if (this.htab[i] == fcode) {
               ent = this.codetab[i];
            } else {/**
 * Implements `if(this.htab[i] >= 0)` returning ``. Non-trivial control flow (≈17 LOC, complexity score 3).
 */

               if (this.htab[i] >= 0) {
                  int disp = hsize_reg - i;
                  if (i == 0) {
                     disp = 1;
                  }

                  do {
                     if ((i -= disp) < 0) {
                        i += hsize_reg;
                     }/**
 * Implements `if(this.htab[i] == fcode)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


                     if (this.htab[i] == fcode) {
                        ent = this.codetab[i];
                        continue label40;
                     }
                  } while(this.htab[i] >= 0);
               }

               this.output(ent, outs);
               ent = c;/**
 * Implements `if(this.free_ent < this.maxmaxcode)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (this.free_ent < this.maxmaxcode) {
                  this.codetab[i] = this.free_ent++;
                  this.htab[i] = fcode;
               } else {
                  this.cl_block(outs);
               }
            }
         }

         this.output(ent, outs);
         this.output(this.EOFCode, outs);
         return;
      }
   }/**
 * Implements `output(int code, OutputStream outs)` returning `void`. Non-trivial control flow (≈38 LOC, complexity score 5).
 */


   void output(int code, OutputStream outs) throws IOException {
      this.cur_accum &= this.masks[this.cur_bits];
      if (this.cur_bits > 0) {
         this.cur_accum |= code << this.cur_bits;
      } else {
         this.cur_accum = code;
      }/**
 * Implements `for(this.cur_bits += this.n_bits; this.cur_bits >= 8; this.cur_bits -= 8)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


      for(this.cur_bits += this.n_bits; this.cur_bits >= 8; this.cur_bits -= 8) {
         this.char_out((byte)(this.cur_accum & 255), outs);
         this.cur_accum >>= 8;
      }/**
 * Implements `if(this.free_ent > this.maxcode || this.clear_flg)` returning ``. Non-trivial control flow (≈13 LOC, complexity score 2).
 */


      if (this.free_ent > this.maxcode || this.clear_flg) {/**
 * Implements `if(this.clear_flg)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (this.clear_flg) {
            this.maxcode = this.MAXCODE(this.n_bits = this.g_init_bits);
            this.clear_flg = false;
         } else {
            ++this.n_bits;
            if (this.n_bits == this.maxbits) {
               this.maxcode = this.maxmaxcode;
            } else {
               this.maxcode = this.MAXCODE(this.n_bits);
            }
         }
      }/**
 * Implements `if(code == this.EOFCode)` returning ``. Non-trivial control flow (≈9 LOC, complexity score 0).
 */


      if (code == this.EOFCode) {/**
 * Implements `while(this.cur_bits > 0)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

         while(this.cur_bits > 0) {
            this.char_out((byte)(this.cur_accum & 255), outs);
            this.cur_accum >>= 8;
            this.cur_bits -= 8;
         }

         this.flush_char(outs);
      }

   }/**
 * Implements `cl_block(OutputStream outs)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   void cl_block(OutputStream outs) throws IOException {
      this.cl_hash(this.hsize);
      this.free_ent = this.ClearCode + 2;
      this.clear_flg = true;
      this.output(this.ClearCode, outs);
   }/**
 * Implements `cl_hash(int hsize)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   void cl_hash(int hsize) {
      for(int i = 0; i < hsize; ++i) {
         this.htab[i] = -1;
      }

   }

   void char_init() {
      this.a_count = 0;
   }/**
 * Implements `char_out(byte c, OutputStream outs)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   void char_out(byte c, OutputStream outs) throws IOException {
      this.accum[this.a_count++] = c;
      if (this.a_count >= 254) {
         this.flush_char(outs);
      }

   }/**
 * Implements `flush_char(OutputStream outs)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   void flush_char(OutputStream outs) throws IOException {/**
 * Implements `if(this.a_count > 0)` returning ``. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

      if (this.a_count > 0) {
         outs.write(this.a_count);
         outs.write(this.accum, 0, this.a_count);
         this.a_count = 0;
      }

   }
}
