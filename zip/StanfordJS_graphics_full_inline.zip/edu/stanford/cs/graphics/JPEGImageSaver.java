package edu.stanford.cs.graphics;
/**
 * Package component providing functionality within this subsystem.
 */


class JPEGImageSaver extends ImageSaver {
   public JPEGImageSaver() {
      super("JPEG", 1);
   }
}
