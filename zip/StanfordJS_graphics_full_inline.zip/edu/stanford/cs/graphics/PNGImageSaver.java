package edu.stanford.cs.graphics;
/**
 * Package component providing functionality within this subsystem.
 */


class PNGImageSaver extends ImageSaver {
   public PNGImageSaver() {
      super("PNG", 2);
   }
}
