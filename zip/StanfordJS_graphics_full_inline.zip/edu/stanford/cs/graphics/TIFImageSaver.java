package edu.stanford.cs.graphics;
/**
 * Package component providing functionality within this subsystem.
 */


class TIFImageSaver extends TIFFImageSaver {
}
