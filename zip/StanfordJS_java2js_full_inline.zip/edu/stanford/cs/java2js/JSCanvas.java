package edu.stanford.cs.java2js;

import java.awt.Component;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JComponent;
/**
 * View component managing paint/repaint cycles and user interaction.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class JSCanvas extends JComponent {
   private double sf = 1.0D;

   public void setScaleFactor(double sf) {
      this.sf = sf;
   }

   public double getScaleFactor() {
      return this.sf;
   }/**
 * Implements `paint(Graphics g)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 0).
 */


   public void paint(Graphics g) {
      Graphics2D g2d = (Graphics2D)g.create();
      g.setColor(this.getBackground());
      g.fillRect(0, 0, this.getWidth(), this.getHeight());
      g2d.scale(this.sf, this.sf);
      super.paint(g2d);
      g2d.dispose();
   }/**
 * Implements `getEnclosingFrame(Component comp)` returning `Frame`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   public static Frame getEnclosingFrame(Component comp) {
      while(comp != null && !(comp instanceof Frame)) {
         comp = ((Component)comp).getParent();
      }

      return (Frame)comp;
   }
}
