package edu.stanford.cs.java2js;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.TreeMap;
/**
 * Package component providing functionality within this subsystem.
 * Handles character/byte streams with buffered I/O where needed.
 */


public class JSCookie {
   public static final String COOKIE_PATH = "/tmp/cookies.txt";/**
 * Implements `set(String name, String value)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public static void set(String name, String value) {
      TreeMap<String, String> cookies = readCookies();
      cookies.put(name, value);
      writeCookies(cookies);
   }

   public static void set(String name, String value, int days) {
      set(name, value);
   }/**
 * Implements `remove(String name)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public static void remove(String name) {
      TreeMap<String, String> cookies = readCookies();
      cookies.remove(name);
      writeCookies(cookies);
   }

   public static String get(String name) {
      return (String)readCookies().get(name);
   }/**
 * Implements `getNames()` returning `String[]`. Non-trivial control flow (≈12 LOC, complexity score 0).
 */


   public static String[] getNames() {
      TreeMap<String, String> cookies = readCookies();
      String[] names = new String[cookies.size()];
      int n = 0;

      String name;
      for(Iterator var4 = cookies.keySet().iterator(); var4.hasNext(); names[n++] = name) {
         name = (String)var4.next();
      }

      return names;
   }/**
 * Implements `readCookies()` returning `TreeMap<String, String>`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈35 LOC, complexity score 7).
 */


   private static TreeMap<String, String> readCookies() {
      TreeMap<String, String> cookies = new TreeMap();
      BufferedReader rd = null;

      try {
         rd = new BufferedReader(new FileReader("/tmp/cookies.txt"));/**
 * Implements `while(true)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈16 LOC, complexity score 2).
 */


         while(true) {
            String line = rd.readLine();
            if (line == null) {
               break;
            }

            int equals = line.indexOf("=");/**
 * Implements `if(equals == -1)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

            if (equals == -1) {
               rd.close();
               throw new RuntimeException("Illegal cookie file");
            }

            String name = line.substring(0, equals);
            String value = line.substring(equals + 1);
            cookies.put(name, value);
         }
      } catch (IOException var7) {
      }/**
 * Implements `if(rd != null)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 2).
 */


      if (rd != null) {
         try {
            rd.close();
         } catch (IOException var6) {
         }
      }

      return cookies;
   }/**
 * Implements `writeCookies(TreeMap<String, String> cookies)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈16 LOC, complexity score 2).
 */


   private static void writeCookies(TreeMap<String, String> cookies) {
      try {
         PrintWriter wr = new PrintWriter(new BufferedWriter(new FileWriter("/tmp/cookies.txt")));
         Iterator var3 = cookies.keySet().iterator();

         while(var3.hasNext()) {
            String name = (String)var3.next();
            String value = (String)cookies.get(name);
            wr.println(name + "=" + value);
         }

         wr.close();
      } catch (IOException var5) {
         throw new RuntimeException("Can't create cookie file");
      }
   }
}
