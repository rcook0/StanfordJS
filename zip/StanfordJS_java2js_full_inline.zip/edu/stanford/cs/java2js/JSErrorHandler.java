package edu.stanford.cs.java2js;
/**
 * Package component providing functionality within this subsystem.
 */


public interface JSErrorHandler {
   void error(String var1);
}
