package edu.stanford.cs.java2js;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.Timer;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 * Uses core collections for buffering, indexing, or caching.
 */


public class JSEvent {
   private static boolean useHeadlessTimer = false;/**
 * Implements `dispatch(ActionListener listener, ActionEvent e)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public static void dispatch(ActionListener listener, ActionEvent e) {
      ArrayList<ActionListener> listeners = new ArrayList();
      listeners.add(listener);
      dispatchList(listeners, e);
   }/**
 * Implements `dispatchList(ArrayList<ActionListener> listeners, ActionEvent e)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈11 LOC, complexity score 1).
 */


   public static void dispatchList(ArrayList<ActionListener> listeners, ActionEvent e) {
      JSTimerTask task = new JSTimerTask(listeners, e);
      if (useHeadlessTimer) {
         (new Thread(task)).start();
      } else {
         Timer swingTimer = new Timer(0, task);
         swingTimer.setRepeats(false);
         swingTimer.start();
      }

   }

   public static ActionEvent createActionEvent(Object source, String command) {
      return new ActionEvent(source, 1001, command);
   }

   public static ActionEvent createActionEvent(Object source, String command, int modifiers) {
      return new ActionEvent(source, 1001, command, modifiers);
   }

   public static boolean isErrorEvent(ActionEvent e) {
      return e instanceof JSErrorEvent;
   }/**
 * Implements `setHeadlessTimer(boolean flag)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public static void setHeadlessTimer(boolean flag) {
      useHeadlessTimer = flag;
      System.setProperty("java.awt.headless", "" + flag);
   }

   public static boolean getHeadlessTimer() {
      return useHeadlessTimer;
   }
}
