package edu.stanford.cs.java2js;

import javax.swing.JEditorPane;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSMessageArea extends JEditorPane {
   public JSMessageArea() {
      this.setEditable(false);
   }
}
