package edu.stanford.cs.java2js;

import java.awt.FlowLayout;
import javax.swing.JComponent;
/**
 * View component managing paint/repaint cycles and user interaction.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class JSPanel extends JComponent {
   public JSPanel() {
      this.setLayout(new FlowLayout());
   }
}
