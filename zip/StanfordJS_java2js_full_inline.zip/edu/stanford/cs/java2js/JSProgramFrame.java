package edu.stanford.cs.java2js;

import javax.swing.JFrame;
/**
 * Top-level Swing window component coordinating layout and lifecycle.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSProgramFrame extends JFrame {
   public JSProgramFrame() {
      this.setDefaultCloseOperation(3);
      new PSGraphicsWriter(this);
   }
}
