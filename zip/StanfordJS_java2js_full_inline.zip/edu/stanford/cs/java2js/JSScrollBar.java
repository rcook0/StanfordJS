package edu.stanford.cs.java2js;

import java.awt.Graphics;
import javax.swing.JScrollBar;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSScrollBar extends JScrollBar {
   public JSScrollBar(int orientation) {
      super(orientation);
   }/**
 * Implements `paint(Graphics g)` returning `void`. Non-trivial control flow (≈14 LOC, complexity score 3).
 */


   public void paint(Graphics g) {
      boolean isPSGraphics = false;

      try {
         Class<?> psGraphics = Class.forName("edu.stanford.cs.psgraphics.PSGraphics");
         isPSGraphics = psGraphics.isInstance(g);
      } catch (Exception var4) {
      }

      if (!isPSGraphics) {
         super.paint(g);
      }

   }
}
