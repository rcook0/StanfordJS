package edu.stanford.cs.java2js;
/**
 * Package component providing functionality within this subsystem.
 */


public interface JSTextSource {
   String getText();
}
