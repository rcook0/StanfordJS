package edu.stanford.cs.java2js;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Iterator;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 * Uses core collections for buffering, indexing, or caching.
 */


class JSTimerTask implements ActionListener, Runnable {
   private ActionEvent event;
   private ArrayList<ActionListener> listeners;

   public JSTimerTask(ArrayList<ActionListener> listeners, ActionEvent e) {
      this.listeners = listeners;
      this.event = e;
   }

   public void run() {
      this.actionPerformed((ActionEvent)null);
   }/**
 * Implements `actionPerformed(ActionEvent e)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 0).
 */


   public void actionPerformed(ActionEvent e) {
      Iterator var3 = this.listeners.iterator();

      while(var3.hasNext()) {
         ActionListener listener = (ActionListener)var3.next();
         listener.actionPerformed(this.event);
      }

   }
}
