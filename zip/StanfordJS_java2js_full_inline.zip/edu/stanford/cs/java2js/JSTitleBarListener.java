package edu.stanford.cs.java2js;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JComponent;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSTitleBarListener implements MouseListener {
   private JComponent target;

   public JSTitleBarListener(JComponent target) {
      this.target = target;
   }

   public void mouseClicked(MouseEvent e) {
      this.target.requestFocus();
   }

   public void mouseEntered(MouseEvent e) {
   }

   public void mouseExited(MouseEvent e) {
   }

   public void mousePressed(MouseEvent e) {
   }

   public void mouseReleased(MouseEvent e) {
   }
}
