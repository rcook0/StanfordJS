package edu.stanford.cs.java2js;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Handles character/byte streams with buffered I/O where needed.
 * Coordinates state across threads using synchronized regions and wait/notify.
 */


class URLReader implements Runnable {
   private String name;
   private ActionListener listener;

   public URLReader(String name, ActionListener listener) {
      this.name = name;
      this.listener = listener;
   }/**
 * Implements `run()` returning `void`. Non-trivial control flow (≈29 LOC, complexity score 4).
 */


   public void run() {
      Object e = null;

      try {
         if (this.name.startsWith("http:/") && !this.name.startsWith("http://")) {
            this.name = this.name.substring(0, 6) + "/" + this.name.substring(6);
         }

         URL url = new URL(this.name);
         InputStream is = url.openStream();
         BufferedReader rd = new BufferedReader(new InputStreamReader(is));
         String result = "";/**
 * Implements `while(true)` returning ``. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


         while(true) {
            String line = rd.readLine();/**
 * Implements `if(line == null)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

            if (line == null) {
               rd.close();
               e = JSEvent.createActionEvent(this, result);
               break;
            }

            result = result + line + "\n";
         }
      } catch (IOException var7) {
         e = new JSErrorEvent(this, var7.getMessage());
      }

      JSEvent.dispatch(this.listener, (ActionEvent)e);
   }
}
