package edu.stanford.cs.jsconsole;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class ConsoleTextPane extends JTextPane implements KeyListener {
   public static final int OUTPUT_STYLE = 0;
   public static final int INPUT_STYLE = 1;
   public static final int ERROR_STYLE = 2;
   private Document document;
   private JSConsole console;
   private SimpleAttributeSet errorAttributes;
   private SimpleAttributeSet inputAttributes;
   private SimpleAttributeSet outputAttributes;
   private int base;
   private int lastChar;

   public ConsoleTextPane(JSConsole console) {
      this.console = console;
      this.addKeyListener(this);
      this.document = this.getDocument();
      this.outputAttributes = new SimpleAttributeSet();
      this.inputAttributes = new SimpleAttributeSet();
      this.errorAttributes = new SimpleAttributeSet();
      this.base = 0;
      this.lastChar = -1;
   }/**
 * Implements `print(String str, int style)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public void print(String str, int style) {
      this.insert(str, this.base, style);
      this.base += str.length();
      this.setCaretPosition(this.base);
   }/**
 * Implements `clear()` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void clear() {
      this.setText("");
      this.base = 0;
   }

   public String getText() {
      return this.getText();
   }/**
 * Implements `getText(int start, int end)` returning `String`. Non-trivial control flow (≈7 LOC, complexity score 2).
 */


   public String getText(int start, int end) {
      try {
         return this.document.getText(start, end - start);
      } catch (BadLocationException var4) {
         throw new RuntimeException(var4);
      }
   }

   public int getLength() {
      return this.document.getLength();
   }/**
 * Implements `cut()` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void cut() {
      this.copy();
      this.deleteSelection();
   }/**
 * Implements `paste()` returning `void`. Non-trivial control flow (≈13 LOC, complexity score 2).
 */


   public void paste() {
      if (this.getSelectionEnd() == this.document.getLength()) {
         int start = this.deleteSelection();
         this.setSelectionStart(start);
         super.paste();
         this.select(this.document.getLength(), this.document.getLength());/**
 * Implements `if(this.document instanceof DefaultStyledDocument)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (this.document instanceof DefaultStyledDocument) {
            DefaultStyledDocument doc = (DefaultStyledDocument)this.document;
            doc.setCharacterAttributes(start, this.getSelectionEnd() - start, this.inputAttributes, true);
         }

      }
   }

   public boolean isPointSelection() {
      return this.getSelectionStart() == this.getSelectionEnd();
   }/**
 * Implements `setInputStyle(int style)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void setInputStyle(int style) {
      if (this.getLength() != 0) {
         throw new RuntimeException("Console styles and colors cannot be changed after I/O has started.");
      } else {
         this.inputAttributes.addAttribute(StyleConstants.Bold, new Boolean((style & 1) != 0));
         this.inputAttributes.addAttribute(StyleConstants.Italic, new Boolean((style & 2) != 0));
      }
   }/**
 * Implements `setInputColor(Color color)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public void setInputColor(Color color) {
      if (this.getLength() != 0) {
         throw new RuntimeException("Console styles and colors cannot be changed after I/O has started.");
      } else {
         this.inputAttributes.addAttribute(StyleConstants.Foreground, color);
      }
   }/**
 * Implements `setErrorStyle(int style)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void setErrorStyle(int style) {
      if (this.getLength() != 0) {
         throw new RuntimeException("Console styles and colors cannot be changed after I/O has started.");
      } else {
         this.errorAttributes.addAttribute(StyleConstants.Bold, new Boolean((style & 1) != 0));
         this.errorAttributes.addAttribute(StyleConstants.Italic, new Boolean((style & 2) != 0));
      }
   }/**
 * Implements `setErrorColor(Color color)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public void setErrorColor(Color color) {
      if (this.getLength() != 0) {
         throw new RuntimeException("Console styles and colors cannot be changed after I/O has started.");
      } else {
         this.errorAttributes.addAttribute(StyleConstants.Foreground, color);
      }
   }/**
 * Implements `keyTyped(KeyEvent e)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


   public void keyTyped(KeyEvent e) {
      if (!e.isMetaDown() && !e.isControlDown()) {
         this.processChar(e.getKeyChar());
         e.consume();
      }
   }/**
 * Implements `keyPressed(KeyEvent e)` returning `void`. Non-trivial control flow (≈15 LOC, complexity score 4).
 */


   public void keyPressed(KeyEvent e) {
      if (!e.isMetaDown() && !e.isControlDown()) {
         switch(e.getKeyCode()) {
         case 37:
            this.processChar(2);
         case 38:
         default:
            break;
         case 39:
            this.processChar(6);
         }

         e.consume();
      }
   }/**
 * Implements `keyReleased(KeyEvent e)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 1).
 */


   public void keyReleased(KeyEvent e) {
      if (!e.isMetaDown() && !e.isControlDown()) {
         e.consume();
      }
   }/**
 * Implements `processChar(int ch)` returning `void`. Non-trivial control flow (≈66 LOC, complexity score 17).
 */


   private void processChar(int ch) {/**
 * Implements `if(ch == 10)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 1).
 */

      if (ch == 10) {
         if (this.lastChar != 13) {
            this.signalEndOfLine();
         }
      } else if (ch == 13) {
         if (this.lastChar != 10) {
            this.signalEndOfLine();
         }
      } else {
         if (this.getCaretPosition() < this.base) {
            this.setCaretPosition(this.getLength());
         }

         int dot = this.getSelectionStart();/**
 * Implements `switch(ch)` returning ``. Non-trivial control flow (≈42 LOC, complexity score 11).
 */

         switch(ch) {
         case 1:
            this.selectAll();
            dot = -1;
            break;
         case 2:
            dot = Math.max(this.getSelectionStart() - 1, this.base);
            break;
         case 3:
            this.copy();
            dot = -1;
            break;
         case 6:
            dot = Math.min(this.getSelectionEnd() + 1, this.getLength());
            break;
         case 8:
         case 127:
            if (dot == this.getSelectionEnd()) {/**
 * Implements `if(dot > this.base)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

               if (dot > this.base) {
                  this.delete(dot - 1, dot);
                  --dot;
               }
            } else {
               dot = this.deleteSelection();
            }
            break;
         case 22:
            this.paste();
            dot = -1;
            break;
         case 24:
            this.cut();
            dot = -1;
            break;
         default:
            if (dot != this.getSelectionEnd()) {
               dot = this.deleteSelection();
            }

            this.insert("" + (char)ch, dot, 1);
            ++dot;
         }/**
 * Implements `if(dot != -1)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


         if (dot != -1) {
            this.select(dot, dot);
            this.setCaretPosition(dot);
         }
      }

      this.lastChar = ch;
   }/**
 * Implements `signalEndOfLine()` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */


   private void signalEndOfLine() {
      int len = this.getLength() - this.base;
      String line = this.getText(this.base, this.base + len);
      this.insert("\n", this.base + len, 0);
      this.base += len + 1;
      this.console.processLine(line);
   }/**
 * Implements `insert(String str, int dot, int style)` returning `void`. Non-trivial control flow (≈16 LOC, complexity score 4).
 */


   private void insert(String str, int dot, int style) {
      try {
         SimpleAttributeSet attributes = this.outputAttributes;/**
 * Implements `switch(style)` returning ``. Non-trivial control flow (≈7 LOC, complexity score 2).
 */

         switch(style) {
         case 1:
            attributes = this.inputAttributes;
            break;
         case 2:
            attributes = this.errorAttributes;
         }

         this.document.insertString(dot, str, attributes);
      } catch (BadLocationException var5) {
      }

   }/**
 * Implements `delete(int p1, int p2)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈7 LOC, complexity score 2).
 */


   private void delete(int p1, int p2) {
      try {
         this.document.remove(p1, p2 - p1);
      } catch (BadLocationException var4) {
         throw new RuntimeException(var4);
      }
   }/**
 * Implements `deleteSelection()` returning `int`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   private int deleteSelection() {
      int start = Math.max(this.base, this.getSelectionStart());
      int end = this.getSelectionEnd();
      if (end <= this.base) {
         return this.getLength();
      } else {
         this.delete(start, end);
         return start;
      }
   }/**
 * Implements `setStyleFromAttributes(Graphics g, AttributeSet attributes)` returning `void`. Non-trivial control flow (≈19 LOC, complexity score 3).
 */


   protected void setStyleFromAttributes(Graphics g, AttributeSet attributes) {
      Font oldFont = this.getFont();
      int style = 0;
      if ((Boolean)attributes.getAttribute(StyleConstants.Bold)) {
         style |= 1;
      }

      if ((Boolean)attributes.getAttribute(StyleConstants.Italic)) {
         style |= 2;
      }

      g.setFont(new Font(oldFont.getName(), style, oldFont.getSize()));
      Color color = (Color)attributes.getAttribute(StyleConstants.Foreground);
      if (color == null) {
         color = this.getForeground();
      }

      g.setColor(color);
   }
}
