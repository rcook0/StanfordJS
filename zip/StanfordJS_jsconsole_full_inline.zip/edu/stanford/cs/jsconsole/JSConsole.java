package edu.stanford.cs.jsconsole;

import edu.stanford.cs.java2js.JSEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JScrollPane;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Uses core collections for buffering, indexing, or caching.
 */


public class JSConsole extends JScrollPane implements NBConsole {
   public static final Font DEFAULT_FONT = Font.decode("Courier New-Bold-18");
   public static final int DEFAULT_MARGIN = 2;
   private ArrayList<ActionListener> actionListeners = new ArrayList();
   private ConsoleTextPane textPane;
   private Font consoleFont;
   private StringBuffer buffer = null;

   public JSConsole() {
      super(20, 30);
      this.consoleFont = DEFAULT_FONT;
      this.textPane = new ConsoleTextPane(this);
      this.textPane.setFont(this.consoleFont);
      this.textPane.setBackground(Color.WHITE);
      this.textPane.setInputColor(Color.BLUE);
      this.textPane.setErrorColor(Color.RED);
      this.textPane.addFocusListener(new JSConsoleFocusListener(this));
      this.setViewportView(this.textPane);
      this.setMargin(2);
   }

   public void setMargin(int pixels) {
      this.setMargin(new Insets(pixels, pixels, pixels, pixels));
   }

   public void setMargin(Insets insets) {
      this.textPane.setMargin(insets);
   }

   public void clear() {
      this.textPane.clear();
   }

   public boolean isSwingComponent() {
      return true;
   }/**
 * Implements `print(Object x)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void print(Object x) {
      if (this.buffer == null) {
         this.textPane.print(x.toString(), 0);
      } else {
         this.buffer.append(x);
      }

   }/**
 * Implements `println()` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void println() {
      if (this.buffer == null) {
         this.textPane.print("\n", 0);
      } else {
         this.buffer.append("\n");
      }

   }/**
 * Implements `println(Object x)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void println(Object x) {
      this.print(x);
      this.println();
   }

   public void log(Object value) {
      this.println(value);
   }

   public void showErrorMessage(String msg) {
      this.textPane.print(msg + "\n", 2);
   }/**
 * Implements `setFont(Font font)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void setFont(Font font) {
      super.setFont(font);
      this.consoleFont = font;
      if (this.textPane != null) {
         this.textPane.setFont(font);
      }

   }

   public Font getFont() {
      return this.consoleFont;
   }/**
 * Implements `requestInput(String prompt)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void requestInput(String prompt) {
      this.requestFocus();
      this.print(prompt);
   }/**
 * Implements `forceInput(String input)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public void forceInput(String input) {
      this.textPane.print(input, 1);
      this.println();
      this.processLine(input);
   }/**
 * Implements `requestFocus()` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


   public void requestFocus() {
      if (this.textPane != null) {
         this.textPane.requestFocus();
      }

   }

   public void addActionListener(ActionListener listener) {
      this.actionListeners.add(listener);
   }

   public void startConsoleLog() {
      this.buffer = new StringBuffer();
   }/**
 * Implements `endConsoleLog()` returning `String`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public String endConsoleLog() {
      String log = this.buffer.toString();
      this.buffer = null;
      return log;
   }/**
 * Implements `processLine(String str)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void processLine(String str) {
      ActionEvent e = new ActionEvent(this, 1001, str);
      JSEvent.dispatchList(this.actionListeners, e);
   }
}
