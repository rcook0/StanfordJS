package edu.stanford.cs.jsconsole;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSConsoleFocusListener implements FocusListener {
   private JSConsole console;

   public JSConsoleFocusListener(JSConsole console) {
      this.console = console;
   }/**
 * Implements `focusGained(FocusEvent e)` returning `void`. Non-trivial control flow (≈12 LOC, complexity score 0).
 */


   public void focusGained(FocusEvent e) {
      e = new FocusEvent(this.console, e.getID());
      FocusListener[] listeners = this.console.getFocusListeners();
      FocusListener[] var6 = listeners;
      int var5 = listeners.length;/**
 * Implements `for(int var4 = 0; var4 < var5; ++var4)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


      for(int var4 = 0; var4 < var5; ++var4) {
         FocusListener listener = var6[var4];
         listener.focusGained(e);
      }

   }/**
 * Implements `focusLost(FocusEvent e)` returning `void`. Non-trivial control flow (≈12 LOC, complexity score 0).
 */


   public void focusLost(FocusEvent e) {
      e = new FocusEvent(this.console, e.getID());
      FocusListener[] listeners = this.console.getFocusListeners();
      FocusListener[] var6 = listeners;
      int var5 = listeners.length;/**
 * Implements `for(int var4 = 0; var4 < var5; ++var4)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


      for(int var4 = 0; var4 < var5; ++var4) {
         FocusListener listener = var6[var4];
         listener.focusLost(e);
      }

   }
}
