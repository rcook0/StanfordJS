package edu.stanford.cs.jsconsole;

import edu.stanford.cs.java2js.JSEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Coordinates state across threads using synchronized regions and wait/notify.
 * Uses core collections for buffering, indexing, or caching.
 */


public class JavaConsole implements NBConsole {
   private ArrayList<ActionListener> listeners = new ArrayList();
   private StringBuffer buffer = null;/**
 * Implements `clear()` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


   public void clear() {
      if (this.buffer != null) {
         this.buffer = new StringBuffer();
      }

   }

   public boolean isSwingComponent() {
      return false;
   }/**
 * Implements `print(Object value)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void print(Object value) {
      if (this.buffer == null) {
         System.out.print(value);
      } else {
         this.buffer.append(value);
      }

   }/**
 * Implements `println()` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void println() {
      if (this.buffer == null) {
         System.out.println();
      } else {
         this.buffer.append("\n");
      }

   }/**
 * Implements `println(Object value)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void println(Object value) {
      if (this.buffer == null) {
         System.out.println(value);
      } else {
         this.buffer.append(value + "\n");
      }

   }

   public void log(Object value) {
      this.println(value);
   }

   public void showErrorMessage(String msg) {
      System.err.println(msg);
   }/**
 * Implements `requestInput(String prompt)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void requestInput(String prompt) {
      System.out.print(prompt);
      Thread t = new Thread(new JavaConsoleMonitor(this));
      t.setDaemon(true);
      t.start();
   }/**
 * Implements `forceInput(String input)` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void forceInput(String input) {
      this.println(input);
      this.processInput(input);
   }

   public void addActionListener(ActionListener listener) {
      this.listeners.add(listener);
   }

   public void startConsoleLog() {
      this.buffer = new StringBuffer();
   }/**
 * Implements `endConsoleLog()` returning `String`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


   public String endConsoleLog() {
      String log = this.buffer.toString();
      this.buffer = null;
      return log;
   }/**
 * Implements `processInput(String str)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void processInput(String str) {
      ActionEvent e = new ActionEvent(this, 1001, str);
      JSEvent.dispatchList(this.listeners, e);
   }
}
