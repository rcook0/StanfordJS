package edu.stanford.cs.jsconsole;

import java.io.IOException;
/**
 * Package component providing functionality within this subsystem.
 * Coordinates state across threads using synchronized regions and wait/notify.
 */


class JavaConsoleMonitor implements Runnable {
   private JavaConsole console;

   public JavaConsoleMonitor(JavaConsole console) {
      this.console = console;
   }/**
 * Implements `run()` returning `void`. This method reads/writes from/to streams or buffers; manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈33 LOC, complexity score 7).
 */


   public void run() {
      try {
         String line = "";
         int lastChar = -1;/**
 * Implements `while(true)` returning ``. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈21 LOC, complexity score 5).
 */


         while(true) {
            int ch = System.in.read();/**
 * Implements `if(ch == -1)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

            if (ch == -1) {
               line = null;
               break;
            }/**
 * Implements `if(ch == 10)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 1).
 */


            if (ch == 10) {
               if (lastChar != 13) {
                  break;
               }
            } else if (ch == 13) {
               if (lastChar != 10) {
                  break;
               }
            } else {
               line = line + (char)ch;
            }

            lastChar = ch;
         }

         this.console.processInput(line);
      } catch (IOException var4) {
         this.console.processInput((String)null);
      }

   }
}
