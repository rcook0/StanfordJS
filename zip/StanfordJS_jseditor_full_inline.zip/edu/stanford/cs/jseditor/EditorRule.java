package edu.stanford.cs.jseditor;

import java.util.regex.Pattern;
/**
 * Package component providing functionality within this subsystem.
 * Implements text analysis using tokenization, regex matching, or parser logic.
 */


class EditorRule {
   String style;
   Pattern pattern;
   String next;
}
