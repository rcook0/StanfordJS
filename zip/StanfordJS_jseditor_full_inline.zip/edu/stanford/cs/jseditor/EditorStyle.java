package edu.stanford.cs.jseditor;

import java.awt.Color;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class EditorStyle {
   Color color;
}
