package edu.stanford.cs.jseditor;
/**
 * Package component providing functionality within this subsystem.
 */


public class HighlighterKey {
   private Object tag;

   public HighlighterKey(Object tag) {
      this.tag = tag;
   }

   public Object getTag() {
      return this.tag;
   }
}
