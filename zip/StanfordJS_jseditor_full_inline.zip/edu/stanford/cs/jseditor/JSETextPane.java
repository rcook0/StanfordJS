package edu.stanford.cs.jseditor;

import java.awt.Color;
import java.awt.Point;
import java.util.HashMap;
import javax.swing.JTextPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.DefaultHighlighter.DefaultHighlightPainter;
import javax.swing.text.Highlighter.HighlightPainter;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 * Uses core collections for buffering, indexing, or caching.
 */


class JSETextPane extends JTextPane implements DocumentListener {
   private HashMap<Color, HighlightPainter> highlighters;
   private JSEditor editor;
   private LineHighlighter highlighter;
   private Style style;
   private StyledDocument doc;
   private boolean lineWrap;

   public JSETextPane(JSEditor editor) {
      this.editor = editor;
      this.highlighters = new HashMap();
      this.doc = this.getStyledDocument();
      this.style = this.doc.getLogicalStyle(0);
      this.doc.addDocumentListener(this);
      this.highlighter = new LineHighlighter();
      this.setHighlighter(this.highlighter);
      this.setOpaque(true);
   }

   public boolean getScrollableTracksViewportWidth() {
      return this.lineWrap || this.getUI().getPreferredSize(this).width <= this.getParent().getSize().width;
   }/**
 * Implements `addBackgroundHighlight(int p1, int p2, Color color)` returning `HighlighterKey`. Non-trivial control flow (≈11 LOC, complexity score 2).
 */


   public HighlighterKey addBackgroundHighlight(int p1, int p2, Color color) {
      Object id = null;

      try {
         id = this.highlighter.addHighlight(p1, p2, this.getPainterForColor(color));
      } catch (BadLocationException var6) {
      }

      this.repaint();
      return id == null ? null : new HighlighterKey(id);
   }

   public void removeBackgroundHighlight(HighlighterKey key) {
      this.highlighter.removeHighlight(key.getTag());
   }/**
 * Implements `createMarker(int offset)` returning `Marker`. Non-trivial control flow (≈7 LOC, complexity score 2).
 */


   public Marker createMarker(int offset) {
      try {
         return new Marker(this.doc.createPosition(offset));
      } catch (BadLocationException var3) {
         throw new RuntimeException(var3.toString());
      }
   }

   public int getOffset(int x, int y) {
      return this.viewToModel(new Point(x, y));
   }/**
 * Implements `getLineNumber(int offset)` returning `int`. Non-trivial control flow (≈15 LOC, complexity score 1).
 */


   public int getLineNumber(int offset) {
      String text = this.getText();
      int p = 0;
      int lineNumber = 0;/**
 * Implements `while(p <= offset)` returning ``. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


      while(p <= offset) {
         p = text.indexOf("\n", p) + 1;
         ++lineNumber;
         if (p == 0) {
            break;
         }
      }

      return lineNumber;
   }/**
 * Implements `getLineStart(int line)` returning `int`. Non-trivial control flow (≈15 LOC, complexity score 1).
 */


   public int getLineStart(int line) {
      String text = this.getText();
      int p = 0;

      do {
         --line;
         if (line <= 0) {
            return p;
         }

         p = text.indexOf("\n", p) + 1;
      } while(p != 0);

      return text.length();
   }

   public void setLineWrap(boolean flag) {
      this.lineWrap = flag;
   }

   public boolean getLineWrap() {
      return this.lineWrap;
   }/**
 * Implements `setTabs(int tabWidth)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void setTabs(int tabWidth) {
      FixedTabSet tabSet = new FixedTabSet(tabWidth);
      this.style.addAttribute(StyleConstants.TabSet, tabSet);
   }/**
 * Implements `changedUpdate(DocumentEvent e)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void changedUpdate(DocumentEvent e) {
      this.editor.setSaveNeeded(true);
      this.editor.fireChangeListeners();
   }

   public void insertUpdate(DocumentEvent e) {
      this.editor.fireChangeListeners();
   }

   public void removeUpdate(DocumentEvent e) {
      this.editor.fireChangeListeners();
   }/**
 * Implements `getPainterForColor(Color color)` returning `HighlightPainter`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈9 LOC, complexity score 1).
 */


   private HighlightPainter getPainterForColor(Color color) {
      HighlightPainter painter = (HighlightPainter)this.highlighters.get(color);/**
 * Implements `if(painter == null)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (painter == null) {
         painter = new DefaultHighlightPainter(color);
         this.highlighters.put(color, painter);
      }

      return (HighlightPainter)painter;
   }
}
