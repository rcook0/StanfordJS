package edu.stanford.cs.jseditor;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.undo.CannotUndoException;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSEditorRedoAction extends AbstractAction {
   private JSEditorUndoHandler handler;
   private JSEditorUndoManager manager;

   public JSEditorRedoAction(JSEditorUndoHandler handler) {
      super("Redo");
      this.setEnabled(false);
      this.handler = handler;
      this.manager = handler.getUndoManager();
   }/**
 * Implements `actionPerformed(ActionEvent e)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 2).
 */


   public void actionPerformed(ActionEvent e) {
      try {
         this.manager.redo();
      } catch (CannotUndoException var3) {
      }

      this.update();
      this.handler.getUndoAction().update();
   }/**
 * Implements `update()` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   protected void update() {
      if (this.manager.canRedo()) {
         this.setEnabled(true);
         this.putValue("Name", this.manager.getRedoPresentationName());
      } else {
         this.setEnabled(false);
         this.putValue("Name", "Undo");
      }

   }
}
