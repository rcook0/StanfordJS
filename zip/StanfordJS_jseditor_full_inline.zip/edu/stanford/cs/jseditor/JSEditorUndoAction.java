package edu.stanford.cs.jseditor;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.undo.CannotUndoException;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSEditorUndoAction extends AbstractAction {
   private JSEditorUndoHandler handler;
   private JSEditorUndoManager manager;

   public JSEditorUndoAction(JSEditorUndoHandler handler) {
      super("Undo");
      this.setEnabled(false);
      this.handler = handler;
      this.manager = handler.getUndoManager();
   }/**
 * Implements `actionPerformed(ActionEvent e)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 2).
 */


   public void actionPerformed(ActionEvent e) {
      try {
         this.manager.undo();
      } catch (CannotUndoException var3) {
      }

      this.update();
      this.handler.getRedoAction().update();
   }/**
 * Implements `update()` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   protected void update() {
      if (this.manager.canUndo()) {
         this.setEnabled(true);
         this.putValue("Name", this.manager.getUndoPresentationName());
      } else {
         this.setEnabled(false);
         this.putValue("Name", "Undo");
      }

   }
}
