package edu.stanford.cs.jseditor;

import javax.swing.undo.UndoManager;
import javax.swing.undo.UndoableEdit;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSEditorUndoManager extends UndoManager {
   public UndoableEdit getLastEdit() {
      return this.editToBeUndone();
   }
}
