package edu.stanford.cs.jseditor;

import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import javax.swing.JScrollBar;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JSScrollBarListener implements AdjustmentListener {
   private JSEditor editor;
   private JScrollBar scrollBar;

   public JSScrollBarListener(JSEditor editor, JScrollBar scrollBar) {
      this.editor = editor;
      this.scrollBar = scrollBar;
   }/**
 * Implements `adjustmentValueChanged(AdjustmentEvent e)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   public void adjustmentValueChanged(AdjustmentEvent e) {
      e = new AdjustmentEvent(this.scrollBar, e.getID(), e.getAdjustmentType(), e.getValue());
      this.editor.fireAdjustmentListeners(e);
   }
}
