package edu.stanford.cs.jseditor;

import javax.swing.text.Position;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class Marker implements Comparable<Marker> {
   private Position pos;

   protected Marker(Position pos) {
      this.pos = pos;
   }

   public int compareTo(Marker marker) {
      return this.pos.getOffset() - marker.pos.getOffset();
   }

   public int getOffset() {
      return this.pos.getOffset();
   }
}
