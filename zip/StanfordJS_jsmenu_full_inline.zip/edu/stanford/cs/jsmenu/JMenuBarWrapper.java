package edu.stanford.cs.jsmenu;

import javax.swing.JMenuBar;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class JMenuBarWrapper extends JMenuBar {
   public JMenuBarWrapper(int dummy) {
   }
}
