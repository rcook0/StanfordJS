package edu.stanford.cs.jsmenu;

import edu.stanford.cs.controller.Updatable;
import edu.stanford.cs.controller.Updater;
import javax.swing.JMenu;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


public class JSMenu extends JMenu implements Updatable {
   private Updater updater = null;

   public JSMenu(String name) {
      super(name);
   }/**
 * Implements `update()` returning `void`. Non-trivial control flow (≈15 LOC, complexity score 2).
 */


   public void update() {
      int n = this.getItemCount();/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


      for(int i = 0; i < n; ++i) {
         Updatable item = (Updatable)this.getItem(i);
         if (item != null) {
            item.update();
         }
      }

      if (this.updater != null) {
         this.updater.update(this);
      }

   }

   public void setUpdater(Updater updater) {
      this.updater = updater;
   }
}
