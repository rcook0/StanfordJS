package edu.stanford.cs.jsmenu;

import edu.stanford.cs.controller.Updatable;
import edu.stanford.cs.controller.Updater;
/**
 * Package component providing functionality within this subsystem.
 */


public class JSMenuBar extends JMenuBarWrapper implements Updatable {
   private Updater updater = null;

   public JSMenuBar() {
      super(initMenuBarProperties());
   }/**
 * Implements `update()` returning `void`. Non-trivial control flow (≈15 LOC, complexity score 2).
 */


   public void update() {
      int n = this.getMenuCount();/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


      for(int i = 0; i < n; ++i) {
         Updatable menu = (Updatable)this.getMenu(i);
         if (menu != null) {
            menu.update();
         }
      }

      if (this.updater != null) {
         this.updater.update(this);
      }

   }

   public void setUpdater(Updater updater) {
      this.updater = updater;
   }/**
 * Implements `initMenuBarProperties()` returning `int`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */


   private static int initMenuBarProperties() {
      System.setProperty("apple.laf.useScreenMenuBar", "true");
      return 0;
   }
}
