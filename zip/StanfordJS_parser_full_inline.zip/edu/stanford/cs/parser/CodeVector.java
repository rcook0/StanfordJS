package edu.stanford.cs.parser;

import edu.stanford.cs.utf8.UTF8;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
/**
 * Package component providing functionality within this subsystem.
 * Uses core collections for buffering, indexing, or caching.
 */


public class CodeVector {
   private ArrayList<Integer> code = new ArrayList();
   private HashMap<String, Integer> labels = new HashMap();
   private HashMap<String, IntList> labelRefs = new HashMap();
   private HashMap<Integer, IntList> intRefs = new HashMap();
   private HashMap<String, IntList> stringRefs = new HashMap();
   private String source = null;
   private int labelCount = 0;

   public void addWord(int word) {
      this.code.add(word);
   }

   public void addInstruction(int op, int addr) {
      this.addWord(op << 24 | addr);
   }

   public int getCurrentAddress() {
      return this.code.size();
   }

   public String newLabel() {
      return "$" + this.labelCount++;
   }

   public void defineLabel(String label) {
      this.defineSymbol(label, this.getCurrentAddress());
   }

   public void defineSymbol(String label, int value) {
      this.labels.put(label, value);
   }

   public boolean isDefined(String label) {
      return this.labels.containsKey(label);
   }/**
 * Implements `getLabel(String label)` returning `int`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public int getLabel(String label) {
      if (this.labels.containsKey(label)) {
         return (Integer)this.labels.get(label);
      } else {
         throw new RuntimeException("Undefined symbol " + label);
      }
   }/**
 * Implements `labelRef(String label)` returning `int`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈14 LOC, complexity score 2).
 */


   public int labelRef(String label) {
      if (this.labels.containsKey(label)) {
         return (Integer)this.labels.get(label);
      } else {
         IntList refs = (IntList)this.labelRefs.get(label);/**
 * Implements `if(refs == null)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (refs == null) {
            refs = new IntList();
            this.labelRefs.put(label, refs);
         }

         refs.add(this.code.size());
         return 0;
      }
   }/**
 * Implements `stringRef(String str)` returning `int`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   public int stringRef(String str) {
      IntList refs = (IntList)this.stringRefs.get(str);/**
 * Implements `if(refs == null)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (refs == null) {
         refs = new IntList();
         this.stringRefs.put(str, refs);
      }

      refs.add(this.code.size());
      return 0;
   }/**
 * Implements `intRef(int n)` returning `int`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈10 LOC, complexity score 1).
 */


   public int intRef(int n) {
      IntList refs = (IntList)this.intRefs.get(n);/**
 * Implements `if(refs == null)` returning ``. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (refs == null) {
         refs = new IntList();
         this.intRefs.put(n, refs);
      }

      refs.add(this.code.size());
      return 0;
   }/**
 * Implements `getCode()` returning `int[]`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈11 LOC, complexity score 0).
 */


   public int[] getCode() {
      this.resolveReferences();
      int n = this.code.size();
      int[] array = new int[n];

      for(int i = 0; i < n; ++i) {
         array[i] = (Integer)this.code.get(i);
      }

      return array;
   }

   public void setSource(String source) {
      this.source = source;
   }

   public String getSource() {
      return this.source;
   }/**
 * Implements `resolveReferences()` returning `void`. This method manipulates collection state (buffers, maps, lists). Non-trivial control flow (≈61 LOC, complexity score 1).
 */


   private void resolveReferences() {
      Iterator var2 = this.labelRefs.keySet().iterator();

      String str;
      int addr;
      Iterator var6;
      while(var2.hasNext()) {
         str = (String)var2.next();
         if (!this.labels.containsKey(str)) {
            throw new RuntimeException("Unresolved reference: " + str);
         }

         IntList refs = (IntList)this.labelRefs.get(str);
         int value = (Integer)this.labels.get(str);
         var6 = refs.iterator();

         while(var6.hasNext()) {
            addr = (Integer)var6.next();
            this.code.set(addr, (Integer)this.code.get(addr) + value);
         }
      }

      var2 = this.stringRefs.keySet().iterator();

      int start;
      IntList refs;
      while(var2.hasNext()) {
         str = (String)var2.next();
         start = this.code.size();
         refs = (IntList)this.stringRefs.get(str);
         int[] words = UTF8.encode(str);

         int addr;
         for(addr = 0; addr < words.length; ++addr) {
            this.code.add(words[addr]);
         }

         Iterator var7 = refs.iterator();

         while(var7.hasNext()) {
            addr = (Integer)var7.next();
            this.code.set(addr, (Integer)this.code.get(addr) + start);
         }
      }

      var2 = this.intRefs.keySet().iterator();

      while(var2.hasNext()) {
         int n = (Integer)var2.next();
         start = this.code.size();
         refs = (IntList)this.intRefs.get(n);
         this.code.add(n);
         var6 = refs.iterator();

         while(var6.hasNext()) {
            addr = (Integer)var6.next();
            this.code.set(addr, (Integer)this.code.get(addr) + start);
         }
      }

   }
}
