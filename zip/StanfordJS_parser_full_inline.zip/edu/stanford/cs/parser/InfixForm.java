package edu.stanford.cs.parser;

import edu.stanford.cs.exp.Expression;
/**
 * Package component providing functionality within this subsystem.
 * Implements text analysis using tokenization, regex matching, or parser logic.
 */


public abstract class InfixForm extends Operator {
   public Expression infixAction(Parser p, Expression lhs) {
      return p.createCompound2(this, lhs, p.readE(this.getInfixPrecedence()));
   }
}
