package edu.stanford.cs.parser;

import java.util.ArrayList;
/**
 * Package component providing functionality within this subsystem.
 * Uses core collections for buffering, indexing, or caching.
 */


class IntList extends ArrayList<Integer> {
}
