package edu.stanford.cs.parser;

import edu.stanford.cs.exp.Expression;
/**
 * Package component providing functionality within this subsystem.
 * Implements text analysis using tokenization, regex matching, or parser logic.
 */


public abstract class NofixOperator extends Operator {
   public Expression prefixAction(Parser p) {
      return p.createCompound0(this);
   }
}
