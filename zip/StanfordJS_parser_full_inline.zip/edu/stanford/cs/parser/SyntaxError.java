package edu.stanford.cs.parser;
/**
 * Package component providing functionality within this subsystem.
 */


public class SyntaxError extends RuntimeException {
   public SyntaxError(String msg) {
      super(msg);
   }
}
