package edu.stanford.cs.programeditor;
/**
 * Package component providing functionality within this subsystem.
 * Coordinates state across threads using synchronized regions and wait/notify.
 */


class EditorTickler implements Runnable {
   private ProgramEditor editor;

   public EditorTickler(ProgramEditor editor) {
      this.editor = editor;
   }/**
 * Implements `run()` returning `void`. Non-trivial control flow (≈14 LOC, complexity score 2).
 */


   public void run() {
      try {
         Thread.sleep(2000L);
      } catch (InterruptedException var3) {
      }

      int n = this.editor.getComponentCount();

      for(int i = 0; i < n; ++i) {
         this.editor.getComponent(i).repaint();
      }

      this.editor.repaint();
   }
}
