package edu.stanford.cs.psgraphics;

import java.awt.Image;
import java.awt.image.ImageObserver;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class DummyObserver implements ImageObserver {/**
 * Implements `imageUpdate(Image img, int infoflags, int x, ...)` returning `boolean`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

   public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {
      System.out.println("imageUpdate");
      return false;
   }
}
