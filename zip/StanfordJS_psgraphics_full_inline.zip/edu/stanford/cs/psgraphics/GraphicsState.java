package edu.stanford.cs.psgraphics;

import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
/**
 * Package component providing functionality within this subsystem.
 * Integrates with AWT/Swing for rendering or event dispatch.
 */


class GraphicsState {
   Color fg;
   Font font;
   Rectangle clip;
}
