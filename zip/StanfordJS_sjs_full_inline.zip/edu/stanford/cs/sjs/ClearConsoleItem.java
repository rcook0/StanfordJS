package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * Console/terminal adapter bridging program text I/O and UI.
 */


class ClearConsoleItem extends JSMenuItem {
   public ClearConsoleItem(SJS app) {
      super("Clear Console");
      this.setActionCommand("ClearConsole");
      this.addActionListener(app.getControlStrip());
   }
}
