package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class CopyItem extends JSMenuItem {
   public CopyItem(SJS app) {
      super("Copy", "C");
   }
}
