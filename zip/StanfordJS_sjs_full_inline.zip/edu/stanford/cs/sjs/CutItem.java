package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class CutItem extends JSMenuItem {
   public CutItem(SJS app) {
      super("Cut", "X");
   }
}
