package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * File/stream helper encapsulating buffered I/O and path operations.
 */


class ExportFileItem extends JSMenuItem {
   public ExportFileItem(SJS app) {
      super("Export");
      this.setActionCommand("Export");
      this.addActionListener(app.getControlStrip());
   }
}
