package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 * Integrates with AWT/Swing and the event dispatch thread for UI-safe operations.
 */


class LargerFontItem extends JSMenuItem {
   public LargerFontItem(SJS app) {
      super("Larger Font", "^EQUALS");
      this.setActionCommand("LargerFont");
      this.addActionListener(app.getControlStrip());
   }
}
