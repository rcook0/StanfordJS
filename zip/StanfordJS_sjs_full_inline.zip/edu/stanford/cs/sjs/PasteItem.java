package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class PasteItem extends JSMenuItem {
   public PasteItem(SJS app) {
      super("Paste", "V");
   }
}
