package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class ResetItem extends JSMenuItem {
   public ResetItem(SJS app) {
      super("Reset", "^R");
      this.setActionCommand("Reset");
      this.addActionListener(app.getControlStrip());
   }
}
