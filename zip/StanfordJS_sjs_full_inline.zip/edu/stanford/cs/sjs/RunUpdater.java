package edu.stanford.cs.sjs;

import edu.stanford.cs.controller.Updatable;
import edu.stanford.cs.controller.Updater;
/**
 * SJS library component providing reusable functionality.
 */


class RunUpdater implements Updater {
   private SJS app;

   public RunUpdater(SJS app) {
      this.app = app;
   }/**
 * Implements `update(Updatable obj)` returning `void`. Non-trivial control flow (≈12 LOC, complexity score 3).
 */


   public void update(Updatable obj) {
      switch(this.app.getSVM().getState()) {
      case 1:
      case 3:
         obj.setEnabled(false);
         break;
      case 2:
      default:
         obj.setEnabled(this.app.isRunEnabled());
      }

   }
}
