package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.Operator;
import edu.stanford.cs.parser.Parser;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSBlockOperator extends Operator {
   public SJSBlockOperator() {
      this.setName("BLOCK");
   }/**
 * Implements `compile(Parser p, Expression[] args, CodeVector cv)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void compile(Parser p, Expression[] args, CodeVector cv) {
      for(int i = 0; i < args.length; ++i) {
         p.compile(args[i], cv);
      }

   }
}
