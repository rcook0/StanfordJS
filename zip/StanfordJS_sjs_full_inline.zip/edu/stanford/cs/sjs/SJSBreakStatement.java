package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.Parser;
import edu.stanford.cs.parser.Statement;
import edu.stanford.cs.parser.SyntaxError;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSBreakStatement extends Statement {/**
 * Implements `prefixAction(Parser p)` returning `Expression`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

   public Expression prefixAction(Parser p) {
      p.verifyToken(";");
      return p.createCompound0(this);
   }/**
 * Implements `compile(Parser p, Expression[] args, CodeVector cv)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */


   public void compile(Parser p, Expression[] args, CodeVector cv) {
      SJSParser jsp = (SJSParser)p;
      String tag = jsp.getBreakLabel();
      if (tag == null) {
         throw new SyntaxError("Illegal use of " + p.markCode("break") + " statement");
      } else {
         cv.addInstruction(64, cv.labelRef(tag));
      }
   }
}
