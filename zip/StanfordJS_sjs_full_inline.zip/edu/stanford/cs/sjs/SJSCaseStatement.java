package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.Parser;
import edu.stanford.cs.parser.Statement;
import edu.stanford.cs.parser.SyntaxError;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSCaseStatement extends Statement {
   public Expression prefixAction(Parser p) {
      throw new SyntaxError("A " + p.markCode("case") + " statement must be inside a " + p.markCode("switch"));
   }/**
 * Implements `compile(Parser p, Expression[] args, CodeVector cv)` returning `void`. Non-trivial control flow (≈22 LOC, complexity score 2).
 */


   public void compile(Parser p, Expression[] args, CodeVector cv) {
      SJSParser jsp = (SJSParser)p;
      String tag = jsp.getNextLabel();
      String skip = null;/**
 * Implements `if(tag != null)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

      if (tag != null) {
         skip = cv.newLabel();
         cv.addInstruction(64, cv.labelRef(skip));
         cv.defineLabel(tag);
      }

      tag = cv.newLabel();
      jsp.setNextLabel(tag);
      String temp = "v_" + jsp.getStatementDepth();
      cv.addInstruction(108, cv.stringRef(temp));
      jsp.compile(args[0], cv);
      cv.addInstruction(48, 0);
      cv.addInstruction(66, cv.labelRef(tag));
      if (skip != null) {
         cv.defineLabel(skip);
      }

   }
}
