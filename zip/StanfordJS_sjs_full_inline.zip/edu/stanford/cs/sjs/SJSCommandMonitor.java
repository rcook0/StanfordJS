package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public interface SJSCommandMonitor {
   void showError(String var1, int var2);

   void update();

   void signalFinished();
}
