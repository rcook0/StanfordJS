package edu.stanford.cs.sjs;

import edu.stanford.cs.svm.SVMConsoleListener;
/**
 * Console/terminal adapter bridging program text I/O and UI.
 */


class SJSConsoleListener extends SVMConsoleListener {
   private SJS app;

   public SJSConsoleListener(SJS app) {
      super(app.getSVM());
      this.app = app;
   }

   protected void processConsoleLine(String line) {
      this.app.processConsoleLine(line);
   }
}
