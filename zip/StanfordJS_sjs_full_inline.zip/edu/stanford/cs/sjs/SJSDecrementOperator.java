package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSDecrementOperator extends SJSPrefixIncDecOperator {
   public int getInstructionCode() {
      return 33;
   }

   public int getSign() {
      return -1;
   }
}
