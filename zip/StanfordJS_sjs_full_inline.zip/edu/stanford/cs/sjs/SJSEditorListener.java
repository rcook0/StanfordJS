package edu.stanford.cs.sjs;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
/**
 * Editor/document component managing text state and actions.
 * Integrates with AWT/Swing and the event dispatch thread for UI-safe operations.
 */


class SJSEditorListener implements ChangeListener {
   private SJS app;

   public SJSEditorListener(SJS app) {
      this.app = app;
   }

   public void stateChanged(ChangeEvent e) {
      this.app.updateControls();
   }
}
