package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.Parser;
import edu.stanford.cs.parser.PrefixOperator;
import java.util.ArrayList;
/**
 * File/stream helper encapsulating buffered I/O and path operations.
 * Implements tokenization/regex parsing for text processing tasks.
 * Uses core collections for caching, buffering, and lookups.
 */


public class SJSFunctionKeyword extends PrefixOperator {/**
 * Implements `prefixAction(Parser p)` returning `Expression`. Non-trivial control flow (≈11 LOC, complexity score 0).
 */

   public Expression prefixAction(Parser p) {
      SJSParser jsp = (SJSParser)p;
      ArrayList<String> oldFunctions = jsp.getFunctions();
      ArrayList<String> oldFormals = jsp.getFormals();
      ArrayList<String> oldLocals = jsp.getLocals();
      Expression fn = jsp.readFunction(false);
      jsp.setFormals(oldFunctions);
      jsp.setFormals(oldFormals);
      jsp.setLocals(oldLocals);
      return fn;
   }

   public void compile(Parser p, Expression[] args, CodeVector cv) {
      cv.addInstruction(19, cv.labelRef(args[0].getName()));
   }
}
