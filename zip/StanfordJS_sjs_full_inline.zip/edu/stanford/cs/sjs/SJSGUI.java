package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 * Coordinates cross-thread operations using synchronized regions or concurrency primitives.
 */


class SJSGUI implements Runnable {
   private boolean trace;
   private boolean traceErrors;

   public SJSGUI(boolean trace, boolean traceErrors) {
      this.trace = trace;
      this.traceErrors = traceErrors;
   }/**
 * Implements `run()` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   public void run() {
      SJS sjs = new SJS();
      sjs.setTraceFlag(this.trace);
      sjs.getSVM().setTraceErrors(this.traceErrors);
      sjs.startAfterSetup("SJS");
   }
}
