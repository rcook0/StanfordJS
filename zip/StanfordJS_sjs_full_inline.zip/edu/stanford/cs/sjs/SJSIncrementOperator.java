package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSIncrementOperator extends SJSPrefixIncDecOperator {
   public int getInstructionCode() {
      return 32;
   }

   public int getSign() {
      return 1;
   }
}
