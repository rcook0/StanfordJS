package edu.stanford.cs.sjs;

import edu.stanford.cs.java2js.JSEvent;
import edu.stanford.cs.java2js.JSFile;
import edu.stanford.cs.java2js.JSFileChooser;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * SJS library component providing reusable functionality.
 * Integrates with AWT/Swing and the event dispatch thread for UI-safe operations.
 */


class SJSLoadListener implements ActionListener {
   private JSFileChooser chooser;
   private SJS app;

   public SJSLoadListener(SJS app, JSFileChooser chooser) {
      this.app = app;
      this.chooser = chooser;
   }/**
 * Implements `actionPerformed(ActionEvent e)` returning `void`. This method performs buffered I/O or logging. Non-trivial control flow (≈10 LOC, complexity score 2).
 */


   public void actionPerformed(ActionEvent e) {
      if (!JSEvent.isErrorEvent(e)) {
         String path = this.chooser.getPath();
         if (path != null && path.length() != 0) {
            this.app.setMainFunction((String)null);
            (new JSFile(path)).read(new SJSLoadFileListener(this.app, path));
         }
      }

   }
}
