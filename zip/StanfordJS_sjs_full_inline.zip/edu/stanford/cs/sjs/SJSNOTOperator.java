package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.Parser;
import edu.stanford.cs.parser.PrefixOperator;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSNOTOperator extends PrefixOperator {/**
 * Implements `compile(Parser p, Expression[] args, CodeVector cv)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

   public void compile(Parser p, Expression[] args, CodeVector cv) {
      p.compile(args[0], cv);
      cv.addInstruction(80, 0);
   }
}
