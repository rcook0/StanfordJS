package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.NofixOperator;
import edu.stanford.cs.parser.Parser;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSNaNOperator extends NofixOperator {
   public void compile(Parser p, Expression[] args, CodeVector cv) {
      cv.addInstruction(97, cv.stringRef("Core.NaN"));
   }
}
