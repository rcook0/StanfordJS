package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.InfixOperator;
import edu.stanford.cs.parser.Parser;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSNotEqualOperator extends InfixOperator {/**
 * Implements `compile(Parser parser, Expression[] args, CodeVector cv)` returning `void`. This method parses or matches text via regex/tokenization. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void compile(Parser parser, Expression[] args, CodeVector cv) {
      parser.compile(args[0], cv);
      parser.compile(args[1], cv);
      cv.addInstruction(49, 0);
   }
}
