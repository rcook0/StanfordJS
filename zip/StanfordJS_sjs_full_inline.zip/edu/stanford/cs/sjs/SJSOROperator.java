package edu.stanford.cs.sjs;

import edu.stanford.cs.exp.Expression;
import edu.stanford.cs.parser.CodeVector;
import edu.stanford.cs.parser.InfixForm;
import edu.stanford.cs.parser.Parser;
/**
 * SJS library component providing reusable functionality.
 * Implements tokenization/regex parsing for text processing tasks.
 */


public class SJSOROperator extends InfixForm {/**
 * Implements `compile(Parser p, Expression[] args, CodeVector cv)` returning `void`. Non-trivial control flow (≈11 LOC, complexity score 0).
 */

   public void compile(Parser p, Expression[] args, CodeVector cv) {
      String tag1 = cv.newLabel();
      String tag2 = cv.newLabel();
      p.compile(args[0], cv);
      cv.addInstruction(65, cv.labelRef(tag1));
      p.compile(args[1], cv);
      cv.addInstruction(64, cv.labelRef(tag2));
      cv.defineLabel(tag1);
      cv.addInstruction(97, cv.stringRef("Core.TRUE"));
      cv.defineLabel(tag2);
   }
}
