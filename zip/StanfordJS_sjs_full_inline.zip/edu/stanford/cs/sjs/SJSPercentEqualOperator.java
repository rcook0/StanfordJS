package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSPercentEqualOperator extends SJSOpEqualOperator {
   public int getInstructionCode() {
      return 37;
   }
}
