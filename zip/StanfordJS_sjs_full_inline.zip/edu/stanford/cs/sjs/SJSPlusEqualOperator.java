package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSPlusEqualOperator extends SJSOpEqualOperator {
   public int getInstructionCode() {
      return 32;
   }
}
