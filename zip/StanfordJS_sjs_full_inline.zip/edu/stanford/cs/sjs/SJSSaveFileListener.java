package edu.stanford.cs.sjs;

import edu.stanford.cs.java2js.JSFile;
import edu.stanford.cs.java2js.JSFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * File/stream helper encapsulating buffered I/O and path operations.
 * Integrates with AWT/Swing and the event dispatch thread for UI-safe operations.
 */


class SJSSaveFileListener implements ActionListener {
   private SJS app;
   private String path;

   public SJSSaveFileListener(SJS app, String path) {
      this.app = app;
      this.path = path;
   }/**
 * Implements `actionPerformed(ActionEvent e)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


   public void actionPerformed(ActionEvent e) {
      SJSEditor editor = this.app.getActiveEditor();
      JSFrame frame = editor.getFrame();
      if (frame != null) {
         frame.setTitle(JSFile.getTail(this.path));
      }

   }
}
