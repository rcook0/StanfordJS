package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSSlashOperator extends SJSArithmeticOperator {
   public int getInstructionCode() {
      return 35;
   }
}
