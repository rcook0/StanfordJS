package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSStarOperator extends SJSArithmeticOperator {
   public int getInstructionCode() {
      return 34;
   }
}
