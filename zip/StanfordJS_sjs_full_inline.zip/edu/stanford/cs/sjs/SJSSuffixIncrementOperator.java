package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


public class SJSSuffixIncrementOperator extends SJSSuffixIncDecOperator {
   public int getInstructionCode() {
      return 32;
   }

   public int getSign() {
      return 1;
   }
}
