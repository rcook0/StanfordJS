package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * File/stream helper encapsulating buffered I/O and path operations.
 */


class SaveFileItem extends JSMenuItem {
   public SaveFileItem(SJS app) {
      super("Save", "S");
      this.setActionCommand("Save");
      this.addActionListener(app.getControlStrip());
   }
}
