package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class SelectAllItem extends JSMenuItem {
   public SelectAllItem(SJS app) {
      super("Select All", "A");
   }
}
