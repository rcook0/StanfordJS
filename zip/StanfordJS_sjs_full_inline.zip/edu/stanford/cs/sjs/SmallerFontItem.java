package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 * Integrates with AWT/Swing and the event dispatch thread for UI-safe operations.
 */


class SmallerFontItem extends JSMenuItem {
   public SmallerFontItem(SJS app) {
      super("Smaller Font", "MINUS");
      this.setActionCommand("SmallerFont");
      this.addActionListener(app.getControlStrip());
   }
}
