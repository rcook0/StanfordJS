package edu.stanford.cs.sjs;
/**
 * SJS library component providing reusable functionality.
 */


class StatementContext {
   String breakLabel;
   String continueLabel;
   String nextLabel;
}
