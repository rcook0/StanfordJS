package edu.stanford.cs.sjs;

import edu.stanford.cs.jsmenu.JSMenuItem;
/**
 * SJS library component providing reusable functionality.
 */


class StopItem extends JSMenuItem {
   public StopItem(SJS app) {
      super("Stop", "PERIOD");
      this.setActionCommand("Stop");
      this.addActionListener(app.getControlStrip());
   }
}
