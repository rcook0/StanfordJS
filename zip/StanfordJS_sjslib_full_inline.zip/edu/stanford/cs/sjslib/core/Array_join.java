package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Component providing functionality within this library.
 */


class Array_join extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈21 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      int nArgs = svm.getArgumentCount();
      String separator = ",";/**
 * Implements `if(nArgs == 1)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (nArgs == 1) {
         svm.checkSignature("Array.indexOf", "S");
         separator = svm.popString();
      }

      String result = "";
      SVMArray array = this.getArray(svm, receiver);

      for(int i = 0; i < array.size(); ++i) {
         if (i > 0) {
            result = result + separator;
         }

         result = result + array.get(i);
      }

      svm.pushString(result);
   }
}
