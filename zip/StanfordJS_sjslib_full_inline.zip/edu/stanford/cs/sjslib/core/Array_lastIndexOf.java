package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Component providing functionality within this library.
 */


class Array_lastIndexOf extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈22 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      int nArgs = svm.getArgumentCount();
      int start = -1;
      if (nArgs == 1) {
         svm.checkSignature("Array.lastIndexOf", "*");
      } else {
         svm.checkSignature("Array.lastIndexOf", "*I");
         start = svm.popInteger();
      }

      Object element = svm.pop().getValue();
      SVMArray array = this.getArray(svm, receiver);/**
 * Implements `for(int i = start; i >= 0; --i)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈6 LOC, complexity score 1).
 */


      for(int i = start; i >= 0; --i) {
         if (((Value)array.get(i)).getValue().equals(element)) {
            svm.pushInteger(i);
            return;
         }
      }

      svm.pushInteger(-1);
   }
}
