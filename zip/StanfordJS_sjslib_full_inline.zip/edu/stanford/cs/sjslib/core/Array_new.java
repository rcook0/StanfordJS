package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Array_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈23 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      SVMArray array = new SVMArray();
      int nArgs = svm.getArgumentCount();
      if (nArgs < 1) {
         svm.checkSignature("Array.new", "");
      } else {
         Value init = Value.UNDEFINED;
         if (nArgs == 1) {
            svm.checkSignature("Array.new", "I");
         } else {
            svm.checkSignature("Array.new", "I*");
            init = svm.pop();
         }

         int n = svm.popInteger();

         for(int i = 0; i < n; ++i) {
            array.add(init);
         }
      }

      svm.push(Value.createObject(array, "Array"));
   }
}
