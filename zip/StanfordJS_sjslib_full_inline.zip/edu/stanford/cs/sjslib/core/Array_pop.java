package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Component providing functionality within this library.
 */


class Array_pop extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈13 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Array.pop", "");
      SVMArray array = this.getArray(svm, receiver);
      int n = array.size();
      if (n == 0) {
         svm.push(Value.UNDEFINED);
      } else {
         Value v = (Value)array.get(n - 1);
         array.remove(n - 1);
         svm.push(v);
      }

   }
}
