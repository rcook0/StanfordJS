package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Component providing functionality within this library.
 */


class Array_shift extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈12 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Array.shift", "");
      SVMArray array = this.getArray(svm, receiver);
      if (array.isEmpty()) {
         svm.push(Value.UNDEFINED);
      } else {
         Value v = (Value)array.get(0);
         array.remove(0);
         svm.push(v);
      }

   }
}
