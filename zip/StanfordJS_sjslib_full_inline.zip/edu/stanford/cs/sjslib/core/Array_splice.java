package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Command-line argument utilities: defines option/flag parsing and usage formatting.
 */


class Array_splice extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈26 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      SVMArray args = new SVMArray();
      int nArgs = svm.getArgumentCount();

      int deleteCount;
      for(deleteCount = 0; deleteCount < nArgs - 2; ++deleteCount) {
         args.add(0, svm.pop());
      }

      deleteCount = svm.popInteger();
      int index = svm.popInteger();
      SVMArray array = this.getArray(svm, receiver);
      SVMArray result = new SVMArray();

      int i;/**
 * Implements `for(i = 0; i < deleteCount; ++i)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      for(i = 0; i < deleteCount; ++i) {
         result.add((Value)array.get(index));
         array.remove(index);
      }

      for(i = 0; i < nArgs - 2; ++i) {
         array.add(index + 1, (Value)args.get(i));
      }

      svm.push(Value.createObject(result, "Array"));
   }
}
