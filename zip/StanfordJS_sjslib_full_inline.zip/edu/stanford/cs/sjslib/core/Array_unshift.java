package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Command-line argument utilities: defines option/flag parsing and usage formatting.
 */


class Array_unshift extends ArrayMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈16 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      SVMArray args = new SVMArray();
      int nArgs = svm.getArgumentCount();

      for(int i = 0; i < nArgs; ++i) {
         args.add(0, svm.pop());
      }

      SVMArray array = this.getArray(svm, receiver);

      for(int i = 0; i < args.size(); ++i) {
         array.add(i, (Value)args.get(i));
      }

      svm.pushInteger(array.size());
   }
}
