package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Character_forDigit extends CharacterMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (receiver != null) {
         throw new RuntimeException("Character methods calls must be static");
      } else {
         svm.checkSignature("Character.digit", "II");
         int radix = svm.popInteger();
         int digit = svm.popInteger();
         svm.pushString("" + Character.forDigit(digit, radix));
      }
   }
}
