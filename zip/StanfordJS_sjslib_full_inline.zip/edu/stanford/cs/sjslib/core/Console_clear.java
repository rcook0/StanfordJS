package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Console_clear extends ConsoleMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Console.clear", "");
      NBConsole console = this.getConsole(svm, receiver);
      if (console != null) {
         console.clear();
      }

      svm.push(Value.UNDEFINED);
   }
}
