package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Console_display extends ConsoleMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      NBConsole console = this.getConsole(svm, receiver);
      svm.checkSignature("Console.println", "*");
      Value v = svm.getValueStackDepth() == 0 ? null : svm.pop();
      if (v != null && v != Value.UNDEFINED) {
         console.println(v);
      }

      svm.push(Value.UNDEFINED);
   }
}
