package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Console_log extends ConsoleMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈11 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      NBConsole console = this.getConsole(svm, receiver);
      if (svm.getArgumentCount() == 0) {
         console.println();
      } else {
         svm.checkSignature("Console.println", "*");
         console.println(svm.stringify(svm.pop()));
      }

      svm.push(Value.UNDEFINED);
   }
}
