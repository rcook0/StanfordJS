package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Console_print extends ConsoleMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method reads/writes from/to streams or buffers. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Console.print", "*");
      NBConsole console = this.getConsole(svm, receiver);
      console.print(svm.stringify(svm.pop()));
      svm.push(Value.UNDEFINED);
   }
}
