package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Console_showErrorMessage extends ConsoleMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Console.showErrorMessage", "S");
      NBConsole console = this.getConsole(svm, receiver);
      console.showErrorMessage("Error: " + svm.pop());
      svm.push(Value.UNDEFINED);
   }
}
