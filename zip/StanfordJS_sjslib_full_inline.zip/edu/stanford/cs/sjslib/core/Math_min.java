package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Math_min extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈21 LOC, complexity score 3).
 */

   public void execute(SVM svm, Value receiver) {
      int nArgs = svm.getArgumentCount();
      if (nArgs == -1) {
         nArgs = 2;
      }

      if (nArgs == 0) {
         throw new RuntimeException("min requires at least one argument");
      } else {
         Value min = svm.pop();/**
 * Implements `for(int i = 1; i < nArgs; ++i)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 1).
 */


         for(int i = 1; i < nArgs; ++i) {
            Value v = svm.pop();
            if (min.getDoubleValue() > v.getDoubleValue()) {
               min = v;
            }
         }

         svm.push(min);
      }
   }
}
