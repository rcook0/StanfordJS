package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Math_pow extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Math.pow", "DD");
      double d2 = svm.popDouble();
      double d1 = svm.popDouble();
      svm.pushDouble(Math.pow(d1, d2));
   }
}
