package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Math_sign extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈12 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Math.sign", "D");
      double d = svm.popDouble();
      if (d == 0.0D) {
         svm.pushInteger(0);
      } else if (d < 0.0D) {
         svm.pushInteger(-1);
      } else {
         svm.pushInteger(1);
      }

   }
}
