package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Number_parseFloat extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method parses tokens/options from input text. Non-trivial control flow (≈10 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Number.parseFloat", "S");

      try {
         svm.pushDouble(Double.parseDouble(svm.popString()));
      } catch (NumberFormatException var4) {
         svm.pushDouble(Double.NaN);
      }

   }
}
