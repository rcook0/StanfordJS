package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Number_parseInt extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method parses tokens/options from input text. Non-trivial control flow (≈15 LOC, complexity score 3).
 */

   public void execute(SVM svm, Value receiver) {
      try {
         if (svm.getArgumentCount() == 2) {
            svm.checkSignature("Number.parseInt", "SI");
            int base = svm.popInteger();
            svm.pushInteger(Integer.parseInt(svm.popString(), base));
         } else {
            svm.checkSignature("Number.parseInt", "S");
            svm.pushInteger(Integer.parseInt(svm.popString()));
         }
      } catch (NumberFormatException var4) {
         svm.pushDouble(Double.NaN);
      }

   }
}
