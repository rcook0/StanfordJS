package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.java2js.JSProgram;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Program_alert extends SVMMethod {/**
 * Implements `execute(SVM svm, Value closure)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value closure) {
      String msg = "";
      if (svm.getArgumentCount() == 1) {
         msg = msg + svm.pop().toString();
      }

      JSProgram.alert(msg);
      svm.push(Value.UNDEFINED);
   }
}
