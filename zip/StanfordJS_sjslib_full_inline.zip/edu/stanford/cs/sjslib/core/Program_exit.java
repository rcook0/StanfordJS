package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Program_exit extends SVMMethod {/**
 * Implements `execute(SVM svm, Value closure)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value closure) {
      int status = 0;
      if (svm.getArgumentCount() == 1) {
         svm.checkSignature("Program.exit", "I");
         status = svm.popInteger();
      }

      System.exit(status);
   }
}
