package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.jsconsole.NBConsole;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Program_getConsole extends SVMMethod {/**
 * Implements `execute(SVM svm, Value closure)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value closure) {
      svm.checkSignature("Program.getConsole", "");
      NBConsole console = svm.getConsole();
      if (console == null) {
         svm.push(Value.UNDEFINED);
      } else {
         svm.push(Value.createObject(console, "Console"));
      }

   }
}
