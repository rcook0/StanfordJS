package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class String_lastIndexOf extends StringMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈13 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (svm.getArgumentCount() == 2) {
         svm.checkSignature("String.lastIndexOf", "SI");
         int k = svm.popInteger();
         String s = svm.popString();
         svm.pushInteger(this.getString(svm, receiver).lastIndexOf(s, k));
      } else {
         svm.checkSignature("String.lastIndexOf", "S");
         String s = svm.popString();
         svm.pushInteger(this.getString(svm, receiver).lastIndexOf(s));
      }

   }
}
