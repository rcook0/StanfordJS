package edu.stanford.cs.sjslib.core;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Timer_setActionCommand extends TimerMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Timer.setActionCommand", "S");
      String cmd = svm.popString();
      this.getTimer(svm, receiver).setActionCommand(cmd);
      svm.push(Value.UNDEFINED);
   }
}
