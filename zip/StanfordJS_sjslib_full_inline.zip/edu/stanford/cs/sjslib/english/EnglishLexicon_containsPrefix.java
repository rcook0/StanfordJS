package edu.stanford.cs.sjslib.english;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class EnglishLexicon_containsPrefix extends EnglishLexiconMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("EnglishLexicon.contains", "S");
      String str = svm.popString().toLowerCase();
      svm.pushBoolean(this.getLexicon(svm, receiver).containsPrefix(str));
   }
}
