package edu.stanford.cs.sjslib.english;

import edu.stanford.cs.english.EnglishLexicon;
import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class EnglishLexicon_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (svm.getArgumentCount() == 0) {
         svm.push(Value.createObject(new EnglishLexicon(), "EnglishLexicon"));
      } else {
         svm.checkSignature("EnglishLexicon.contains", "I");
         int len = svm.popInteger();
         svm.push(Value.createObject(new EnglishLexicon(len), "EnglishLexicon"));
      }

   }
}
