package edu.stanford.cs.sjslib.file;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
import edu.stanford.cs.svm.SVMMethod;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
/**
 * Component providing functionality within this library.
 * Reads from/writes to streams for usage/help output and error reporting.
 */


class File_readLines extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈24 LOC, complexity score 3).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("File.readLines", "S");
      String filename = svm.popString();

      try {
         File file = new File(SJSFileClass.expandPathname(svm, filename));
         BufferedReader rd = new BufferedReader(new FileReader(file));
         SVMArray lines = new SVMArray();/**
 * Implements `while(true)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈10 LOC, complexity score 1).
 */


         while(true) {
            String line = rd.readLine();/**
 * Implements `if(line == null)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

            if (line == null) {
               rd.close();
               svm.push(Value.createObject(lines, "Array"));
               break;
            }

            lines.add(Value.createString(line));
         }
      } catch (IOException var8) {
         svm.push(Value.UNDEFINED);
      }

   }
}
