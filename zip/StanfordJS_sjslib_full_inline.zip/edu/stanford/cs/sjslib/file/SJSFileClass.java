package edu.stanford.cs.sjslib.file;

import edu.stanford.cs.sjs.SJS;
import edu.stanford.cs.sjs.SJSVM;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSFileClass extends SVMClass {
   public SJSFileClass() {
      this.defineMethod("chooseFile", new File_chooseFile());
      this.defineMethod("read", new File_read());
      this.defineMethod("readLines", new File_readLines());
   }/**
 * Implements `expandPathname(SVM svm, String pathname)` returning `String`. Non-trivial control flow (≈17 LOC, complexity score 3).
 */


   protected static String expandPathname(SVM svm, String pathname) {
      String cwd = ".";
      SJS app = ((SJSVM)svm).getApplication();
      if (app != null) {
         cwd = app.getCurrentDirectory();
      }

      if (pathname.startsWith("/")) {
         return pathname;
      } else {
         if (!cwd.endsWith("/")) {
            cwd = cwd + "/";
         }

         return cwd + pathname;
      }
   }
}
