package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
import java.awt.Color;
/**
 * Component providing functionality within this library.
 */


class Color_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method parses tokens/options from input text. Non-trivial control flow (≈40 LOC, complexity score 4).
 */

   public void execute(SVM svm, Value receiver) {
      Value v = null;
      int nArgs = svm.getArgumentCount();
      int type;
      int rgb;/**
 * Implements `if(nArgs == 1)` returning ``. This method parses tokens/options from input text. Non-trivial control flow (≈16 LOC, complexity score 2).
 */

      if (nArgs == 1) {
         v = svm.pop();
         type = v.getType();
         int rgb = false;
         if (type == 73) {
            rgb = v.getIntegerValue();
         } else {
            if (type != 83) {
               throw new RuntimeException("Illegal color specification");
            }

            rgb = Integer.parseInt(v.getStringValue(), 16);
         }

         v = Value.createObject(new Color(rgb), "Color");
      } else {
         int gg;/**
 * Implements `if(nArgs == 4)` returning ``. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

         if (nArgs == 4) {
            svm.checkSignature("Color.new", "IIII");
            type = svm.popInteger();
            rgb = svm.popInteger();
            gg = svm.popInteger();
            int rr = svm.popInteger();
            v = Value.createObject(new Color(rr, gg, rgb, type), "Color");
         } else {
            svm.checkSignature("Color.new", "III");
            type = svm.popInteger();
            rgb = svm.popInteger();
            gg = svm.popInteger();
            v = Value.createObject(new Color(gg, rgb, type), "Color");
         }
      }

      svm.push(v);
   }
}
