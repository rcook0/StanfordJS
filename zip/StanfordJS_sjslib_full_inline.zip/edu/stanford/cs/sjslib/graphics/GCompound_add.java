package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GObject;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GCompound_add extends GCompoundMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈15 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (svm.getArgumentCount() == 3) {
         svm.checkSignature("GCompound.add", "ODD");
         double y = svm.popDouble();
         double x = svm.popDouble();
         GObject gobj = (GObject)svm.pop().getValue();
         this.getGCompound(svm, receiver).add(gobj, x, y);
      } else {
         svm.checkSignature("GCompound.add", "O");
         GObject gobj = (GObject)svm.pop().getValue();
         this.getGCompound(svm, receiver).add(gobj);
      }

      svm.push(Value.UNDEFINED);
   }
}
