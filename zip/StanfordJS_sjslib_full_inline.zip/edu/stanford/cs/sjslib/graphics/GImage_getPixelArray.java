package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
/**
 * Component providing functionality within this library.
 */


class GImage_getPixelArray extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈19 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.getPixelArray", "");
      int[][] pixels = this.getGImage(svm, receiver).getPixelArray();
      int height = pixels.length;
      int width = pixels[0].length;
      SVMArray array = new SVMArray();/**
 * Implements `for(int i = 0; i < height; ++i)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈9 LOC, complexity score 0).
 */


      for(int i = 0; i < height; ++i) {
         SVMArray row = new SVMArray();

         for(int j = 0; j < width; ++j) {
            row.add(Value.createInteger(pixels[i][j]));
         }

         array.add(Value.createObject(row, "Array"));
      }

      svm.push(Value.createObject(array, "Array"));
   }
}
