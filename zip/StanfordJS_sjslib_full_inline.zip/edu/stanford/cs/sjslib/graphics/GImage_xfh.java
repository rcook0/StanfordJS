package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GImage;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GImage_xfh extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈18 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.xfh", "*");
      GImage image = (GImage)svm.pop().getValue();
      int[][] array = image.getPixelArray();
      int height = array.length;
      int width = array[0].length;/**
 * Implements `for(int i = 0; i < height; ++i)` returning ``. Non-trivial control flow (≈8 LOC, complexity score 0).
 */


      for(int i = 0; i < height; ++i) {/**
 * Implements `for(int j = 0; j < width / 2; ++j)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

         for(int j = 0; j < width / 2; ++j) {
            int k = width - j - 1;
            int temp = array[i][j];
            array[i][j] = array[i][k];
            array[i][k] = temp;
         }
      }

      svm.push(Value.createObject(new GImage(array), "GImage"));
   }
}
