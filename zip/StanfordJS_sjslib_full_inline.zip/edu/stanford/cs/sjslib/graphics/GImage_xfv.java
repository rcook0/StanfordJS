package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GImage;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GImage_xfv extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈15 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.xfv", "*");
      GImage image = (GImage)svm.pop().getValue();
      int[][] array = image.getPixelArray();
      int height = array.length;/**
 * Implements `for(int p1 = 0; p1 < height / 2; ++p1)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


      for(int p1 = 0; p1 < height / 2; ++p1) {
         int p2 = height - p1 - 1;
         int[] temp = array[p1];
         array[p1] = array[p2];
         array[p2] = temp;
      }

      svm.push(Value.createObject(new GImage(array), "GImage"));
   }
}
