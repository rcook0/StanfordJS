package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GImage;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GImage_xgs extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈16 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.xgs", "*");
      GImage image = (GImage)svm.pop().getValue();
      int[][] array = image.getPixelArray();
      int height = array.length;
      int width = array[0].length;/**
 * Implements `for(int i = 0; i < height; ++i)` returning ``. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


      for(int i = 0; i < height; ++i) {/**
 * Implements `for(int j = 0; j < width; ++j)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         for(int j = 0; j < width; ++j) {
            int xx = this.computeLuminosity(array[i][j]);
            array[i][j] = GImage.createRGBPixel(xx, xx, xx);
         }
      }

      svm.push(Value.createObject(new GImage(array), "GImage"));
   }/**
 * Implements `computeLuminosity(int pixel)` returning `int`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */


   private int computeLuminosity(int pixel) {
      int r = GImage.getRed(pixel);
      int g = GImage.getGreen(pixel);
      int b = GImage.getBlue(pixel);
      return (int)Math.floor(0.299D * (double)r + 0.587D * (double)g + 0.114D * (double)b + 0.5D);
   }
}
