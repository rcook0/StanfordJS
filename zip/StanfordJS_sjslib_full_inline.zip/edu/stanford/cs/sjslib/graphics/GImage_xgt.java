package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GImage;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GImage_xgt extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈21 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.xgt", "*");
      GImage image = (GImage)svm.pop().getValue();
      int[][] array = image.getPixelArray();
      int height = array.length;
      int width = array[0].length;/**
 * Implements `for(int i = 0; i < height; ++i)` returning ``. Non-trivial control flow (≈11 LOC, complexity score 1).
 */


      for(int i = 0; i < height; ++i) {/**
 * Implements `for(int j = 0; j < width; ++j)` returning ``. Non-trivial control flow (≈9 LOC, complexity score 1).
 */

         for(int j = 0; j < width; ++j) {
            int pixel = array[i][j];
            int r = GImage.getRed(pixel);
            int g = GImage.getGreen(pixel);
            int b = GImage.getBlue(pixel);
            if (g > 2 * Math.max(r, b)) {
               array[i][j] = 0;
            }
         }
      }

      svm.push(Value.createObject(new GImage(array), "GImage"));
   }
}
