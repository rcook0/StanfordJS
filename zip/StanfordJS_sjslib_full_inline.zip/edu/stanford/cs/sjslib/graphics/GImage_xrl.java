package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GImage;
import edu.stanford.cs.java2js.JSImage;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GImage_xrl extends GImageMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈16 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GImage.xrl", "*");
      GImage image = (GImage)svm.pop().getValue();
      int[][] array = image.getPixelArray();
      int height = array.length;
      int width = array[0].length;
      int[][] newArray = JSImage.createPixelArray(width, height);/**
 * Implements `for(int i = 0; i < height; ++i)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */


      for(int i = 0; i < height; ++i) {
         for(int j = 0; j < width; ++j) {
            newArray[width - j - 1][i] = array[i][j];
         }
      }

      svm.push(Value.createObject(new GImage(newArray), "GImage"));
   }
}
