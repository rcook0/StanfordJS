package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GLabel_setLabel extends GLabelMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GLabel.setLabel", "S");
      String str = svm.popString();
      this.getGLabel(svm, receiver).setLabel(str);
      svm.push(Value.UNDEFINED);
   }
}
