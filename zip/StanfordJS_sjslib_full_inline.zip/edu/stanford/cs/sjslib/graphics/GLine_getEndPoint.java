package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GPoint;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GLine_getEndPoint extends GLineMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GLine.getEndPoint", "");
      GPoint pt = this.getGLine(svm, receiver).getEndPoint();
      svm.push(Value.createObject(pt, "GPoint"));
   }
}
