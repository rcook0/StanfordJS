package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GLine;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class GLine_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GLine.new", "DDDD");
      double y2 = svm.popDouble();
      double x2 = svm.popDouble();
      double y1 = svm.popDouble();
      double x1 = svm.popDouble();
      svm.push(Value.createObject(new GLine(x1, y1, x2, y2), "GLine"));
   }
}
