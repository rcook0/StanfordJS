package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GObject_move extends GObjectMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GObject.move", "DD");
      double dy = svm.popDouble();
      double dx = svm.popDouble();
      this.getGObject(svm, receiver).move(dx, dy);
      svm.push(Value.UNDEFINED);
   }
}
