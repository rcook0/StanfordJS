package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GObject_movePolar extends GObjectMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GObject.movePolar", "DD");
      double theta = svm.popDouble();
      double r = svm.popDouble();
      this.getGObject(svm, receiver).movePolar(r, theta);
      svm.push(Value.UNDEFINED);
   }
}
