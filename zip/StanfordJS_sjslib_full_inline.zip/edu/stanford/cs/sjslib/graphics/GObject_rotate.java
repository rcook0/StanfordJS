package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GObject_rotate extends GObjectMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GObject.rotate", "D");
      double theta = svm.popDouble();
      this.getGObject(svm, receiver).rotate(theta);
      svm.push(Value.UNDEFINED);
   }
}
