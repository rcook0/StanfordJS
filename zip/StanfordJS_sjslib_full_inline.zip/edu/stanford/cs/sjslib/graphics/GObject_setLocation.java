package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GPoint;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GObject_setLocation extends GObjectMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈13 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (svm.getArgumentCount() == 1) {
         svm.checkSignature("GObject.setLocation", "O");
         GPoint pt = (GPoint)svm.pop().getValue();
         this.getGObject(svm, receiver).setLocation(pt.getX(), pt.getY());
      } else {
         svm.checkSignature("GObject.setLocation", "DD");
         double y = svm.popDouble();
         double x = svm.popDouble();
         this.getGObject(svm, receiver).setLocation(x, y);
      }

   }
}
