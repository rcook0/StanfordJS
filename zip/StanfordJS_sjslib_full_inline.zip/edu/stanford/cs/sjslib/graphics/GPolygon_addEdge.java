package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GPolygon_addEdge extends GPolygonMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GPolygon.addEdge", "DD");
      double dy = svm.popDouble();
      double dx = svm.popDouble();
      this.getGPolygon(svm, receiver).addEdge(dx, dy);
      svm.push(Value.UNDEFINED);
   }
}
