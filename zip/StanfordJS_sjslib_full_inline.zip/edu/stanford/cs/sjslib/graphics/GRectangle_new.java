package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GRectangle;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class GRectangle_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GRectangle.new", "DDDD");
      double height = svm.popDouble();
      double width = svm.popDouble();
      double y = svm.popDouble();
      double x = svm.popDouble();
      svm.push(Value.createObject(new GRectangle(x, y, width, height), "GRectangle"));
   }
}
