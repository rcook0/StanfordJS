package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Command-line argument utilities: defines option/flag parsing and usage formatting.
 */


class GRoundRect_setFilled extends GRoundRectMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GRoundRect.setFilled", "B");
      boolean flag = svm.popBoolean();
      this.getGRoundRect(svm, receiver).setFilled(flag);
      svm.push(Value.UNDEFINED);
   }
}
