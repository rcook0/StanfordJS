package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GTransform;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GTransform_createInverse extends GTransformMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GTransform.createInverse", "");
      GTransform t = this.getGTransform(svm, receiver).createInverse();
      svm.push(Value.createObject(t, "GTransform"));
   }
}
