package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.graphics.GTransform;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class GTransform_new extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈34 LOC, complexity score 3).
 */

   public void execute(SVM svm, Value receiver) {
      int nArgs = svm.getArgumentCount();/**
 * Implements `if(nArgs == 0)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

      if (nArgs == 0) {
         svm.checkSignature("GTransform.new", "");
         svm.push(Value.createObject(new GTransform(), "GTransform"));
      } else if (nArgs == 1) {
         svm.checkSignature("GTransform.new", "O");
         GTransform t = (GTransform)svm.pop().getValue();
         svm.push(Value.createObject(new GTransform(t), "GTransform"));
      } else {
         double d;
         double c;
         double b;
         double a;/**
 * Implements `if(nArgs == 4)` returning ``. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

         if (nArgs == 4) {
            svm.checkSignature("GTransform.new", "DDDD");
            d = svm.popDouble();
            c = svm.popDouble();
            b = svm.popDouble();
            a = svm.popDouble();
            svm.push(Value.createObject(new GTransform(a, b, c, d), "GTransform"));
         } else {
            svm.checkSignature("GTransform.new", "DDDDDD");
            d = svm.popDouble();
            c = svm.popDouble();
            b = svm.popDouble();
            a = svm.popDouble();
            double b = svm.popDouble();
            double a = svm.popDouble();
            svm.push(Value.createObject(new GTransform(a, b, a, b, c, d), "GTransform"));
         }
      }

   }
}
