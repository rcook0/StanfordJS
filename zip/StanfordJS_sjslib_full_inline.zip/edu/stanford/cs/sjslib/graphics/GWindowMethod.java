package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.sjs.SJSGWindow;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


abstract class GWindowMethod extends SVMMethod {/**
 * Implements `getGWindow(SVM svm, Value receiver)` returning `SJSGWindow`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */

   public SJSGWindow getGWindow(SVM svm, Value receiver) {
      if (receiver == null) {
         throw new RuntimeException("No window specified");
      } else {
         return (SJSGWindow)receiver.getValue();
      }
   }
}
