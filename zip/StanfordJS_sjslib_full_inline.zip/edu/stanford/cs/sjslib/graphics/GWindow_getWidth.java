package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.sjs.SJSGWindow;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GWindow_getWidth extends GWindowMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GWindow.getWidth", "");
      SJSGWindow gw = this.getGWindow(svm, receiver);
      svm.pushDouble((double)gw.getWidth());
   }
}
