package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.sjs.SJSGWindow;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GWindow_waitForClick extends GWindowMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GWindow.waitForClick", "");
      SJSGWindow gw = this.getGWindow(svm, receiver);
      gw.enableMouseListener();
      gw.repaint();
      gw.setState(1);
      svm.setState(6);
   }
}
