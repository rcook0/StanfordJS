package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.sjs.SJSGWindow;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class GWindow_waitForEvent extends GWindowMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("GWindow.waitForEvent", "");
      SJSGWindow gw = this.getGWindow(svm, receiver);
      gw.enableMouseListener();
      gw.enableMouseMotionListener();
      gw.enableKeyListener();
      gw.repaint();
      gw.setState(2);
      svm.setState(6);
   }
}
