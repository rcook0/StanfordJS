package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class KeyEvent_getSource extends KeyEventMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("KeyEvent.getSource", "");
      Object source = this.getKeyEvent(svm, receiver).getSource();
      Value v = new Value(79, source);
      String className = source.getClass().getName();
      className = className.substring(className.lastIndexOf(".") + 1);
      v.setClassName(className);
      svm.push(v);
   }
}
