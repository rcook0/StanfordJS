package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMConstant;
/**
 * Component providing functionality within this library.
 */


class MouseEvent_TYPE extends SVMConstant {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("MouseEvent.TYPE", "");
      svm.pushInteger(300);
   }
}
