package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class MouseEvent_getID extends MouseEventMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈25 LOC, complexity score 7).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("MouseEvent.getID", "");
      int id = this.getMouseEvent(svm, receiver).getID();/**
 * Implements `switch(id)` returning ``. Non-trivial control flow (≈20 LOC, complexity score 7).
 */

      switch(id) {
      case 500:
         svm.pushInteger(301);
         break;
      case 501:
         svm.pushInteger(304);
         break;
      case 502:
         svm.pushInteger(305);
         break;
      case 503:
         svm.pushInteger(303);
         break;
      case 504:
      case 505:
      default:
         throw new RuntimeException("Illegal event type");
      case 506:
         svm.pushInteger(302);
      }

   }
}
