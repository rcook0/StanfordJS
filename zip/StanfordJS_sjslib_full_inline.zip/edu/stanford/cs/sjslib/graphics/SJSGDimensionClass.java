package edu.stanford.cs.sjslib.graphics;

import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSGDimensionClass extends SVMClass {
   public SJSGDimensionClass() {
      this.defineMethod("new", new GDimension_new());
      this.defineMethod("getWidth", new GDimension_getWidth());
      this.defineMethod("getHeight", new GDimension_getHeight());
   }
}
