package edu.stanford.cs.sjslib.graphics;
/**
 * Component providing functionality within this library.
 */


public class SJSGOvalClass extends SJSGObjectClass {
   public SJSGOvalClass() {
      this.defineMethod("new", new GOval_new());
      this.defineMethod("setFilled", new GOval_setFilled());
      this.defineMethod("setFillColor", new GOval_setFillColor());
      this.defineMethod("getFillColor", new GOval_getFillColor());
      this.defineMethod("isFilled", new GOval_isFilled());
      this.defineMethod("setBounds", new GOval_setBounds());
   }
}
