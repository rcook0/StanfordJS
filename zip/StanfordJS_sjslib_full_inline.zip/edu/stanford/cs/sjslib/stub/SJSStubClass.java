package edu.stanford.cs.sjslib.stub;

import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSStubClass extends SVMClass {
   public SJSStubClass() {
      this.defineMethod("new", new Stub_new());
   }
}
