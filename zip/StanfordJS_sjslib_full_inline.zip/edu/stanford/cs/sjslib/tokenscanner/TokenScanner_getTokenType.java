package edu.stanford.cs.sjslib.tokenscanner;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class TokenScanner_getTokenType extends TokenScannerMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method parses tokens/options from input text. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("TokenScanner.getTokenType", "S");
      String token = svm.popString();
      svm.pushInteger(this.getTokenScanner(svm, receiver).getTokenType(token));
   }
}
