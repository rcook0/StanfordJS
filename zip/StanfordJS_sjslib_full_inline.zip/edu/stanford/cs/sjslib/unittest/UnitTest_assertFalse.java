package edu.stanford.cs.sjslib.unittest;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
import edu.stanford.cs.unittest.UnitTest;
/**
 * Command-line argument utilities: defines option/flag parsing and usage formatting.
 */


class UnitTest_assertFalse extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈15 LOC, complexity score 2).
 */

   public void execute(SVM svm, Value receiver) {
      UnitTest.setConsole(svm.getConsole());
      boolean flag = svm.popBoolean();
      switch(svm.getArgumentCount()) {
      case 1:
         UnitTest.assertFalse(flag);
         break;
      case 2:
         UnitTest.assertFalse(svm.popString(), flag);
         break;
      default:
         throw new RuntimeException("Illegal call to assertFalse");
      }

   }
}
