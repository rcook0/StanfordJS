package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
/**
 * Component providing functionality within this library.
 */


class Grid {
   private Value[] elements;
   private int nRows;
   private int nCols;

   public Grid(int nRows, int nCols) {
      this.resize(nRows, nCols);
   }

   public int numRows() {
      return this.nRows;
   }

   public int numCols() {
      return this.nCols;
   }/**
 * Implements `resize(int nRows, int nCols)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */


   public void resize(int nRows, int nCols) {/**
 * Implements `if(nRows >= 0 && nCols >= 0)` returning ``. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

      if (nRows >= 0 && nCols >= 0) {
         this.nRows = nRows;
         this.nCols = nCols;
         this.elements = new Value[nRows * nCols];
      } else {
         throw new RuntimeException("Illegal grid size");
      }
   }

   public boolean inBounds(int row, int col) {
      return row >= 0 && col >= 0 && row < this.nRows && col < this.nCols;
   }/**
 * Implements `get(int row, int col)` returning `Value`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public Value get(int row, int col) {
      if (!this.inBounds(row, col)) {
         throw new RuntimeException("get: Grid indices out of bounds");
      } else {
         return this.elements[row * this.nCols + col];
      }
   }/**
 * Implements `set(int row, int col, Value value)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 1).
 */


   public void set(int row, int col, Value value) {
      if (!this.inBounds(row, col)) {
         throw new RuntimeException("set: Grid indices out of bounds");
      } else {
         this.elements[row * this.nCols + col] = value;
      }
   }/**
 * Implements `toString()` returning `String`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈23 LOC, complexity score 2).
 */


   public String toString() {
      String str = "";/**
 * Implements `for(int i = 0; i < this.nRows; ++i)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈17 LOC, complexity score 2).
 */


      for(int i = 0; i < this.nRows; ++i) {
         if (i > 0) {
            str = str + ", ";
         }

         str = str + "{";/**
 * Implements `for(int j = 0; j < this.nCols; ++j)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈7 LOC, complexity score 1).
 */


         for(int j = 0; j < this.nCols; ++j) {
            if (j > 0) {
               str = str + ", ";
            }

            str = str + this.get(i, j).toString();
         }

         str = str + "}";
      }

      return "{" + str + "}";
   }
}
