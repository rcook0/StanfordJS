package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


abstract class GridMethod extends SVMMethod {
   public Grid getGrid(SVM svm, Value receiver) {
      return receiver == null ? (Grid)svm.pop().getValue() : (Grid)receiver.getValue();
   }
}
