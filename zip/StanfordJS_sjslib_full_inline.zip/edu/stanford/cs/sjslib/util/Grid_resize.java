package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Grid_resize extends GridMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈7 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Grid.resize", "II");
      int nCols = svm.popInteger();
      int nRows = svm.popInteger();
      this.getGrid(svm, receiver).resize(nRows, nCols);
      svm.push(Value.UNDEFINED);
   }
}
