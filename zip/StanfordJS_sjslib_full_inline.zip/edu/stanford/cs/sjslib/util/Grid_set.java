package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Grid_set extends GridMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈8 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Grid.set", "II*");
      Value v = svm.pop();
      int row = svm.popInteger();
      int col = svm.popInteger();
      this.getGrid(svm, receiver).set(row, col, v);
      svm.push(Value.UNDEFINED);
   }
}
