package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
import edu.stanford.cs.svm.SVMObject;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


class Map_create extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈12 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      SVMObject m = new SVMObject(svm);
      int nArgs = svm.getArgumentCount();/**
 * Implements `for(int i = 0; i < nArgs; i += 2)` returning ``. This method manipulates collection state (maps/lists). Non-trivial control flow (≈5 LOC, complexity score 0).
 */


      for(int i = 0; i < nArgs; i += 2) {
         Value v = svm.pop();
         String k = svm.popString();
         m.put(k, v);
      }

      svm.push(Value.createObject(m, "Map"));
   }
}
