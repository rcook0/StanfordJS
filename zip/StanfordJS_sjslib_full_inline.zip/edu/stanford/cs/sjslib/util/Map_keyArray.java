package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMArray;
import java.util.Iterator;
/**
 * Component providing functionality within this library.
 */


class Map_keyArray extends MapMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈11 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      SVMArray array = new SVMArray();
      Iterator var5 = this.getMap(svm, receiver).keySet().iterator();

      while(var5.hasNext()) {
         String key = (String)var5.next();
         array.add(Value.createString(key));
      }

      svm.push(Value.createObject(array, "Array"));
   }
}
