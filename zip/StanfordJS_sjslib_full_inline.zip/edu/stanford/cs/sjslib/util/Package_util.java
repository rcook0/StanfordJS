package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMPackage;
/**
 * General-purpose utility class supporting common operations across the codebase.
 * Uses collections to model flags, option tables, and parsed values.
 */


public class Package_util extends SVMPackage {
   private String[] DEPENDENCIES = new String[]{"edu.stanford.cs.sjslib.util", "edu.stanford.cs.svm", "java.awt"};
   private String[] WRAPPER = new String[]{"", "/* Wrapper to read in the unittest package */", "", "var ActionEvent = java_awt.ActionEvent;", "var ArrayList = edu_stanford_cs_svm.SVMArray;", "var Grid = edu_stanford_cs_sjslib_util.Grid;", "var Map = edu_stanford_cs_svm.SVMObject;", "var Queue = edu_stanford_cs_sjslib_util.Queue;", "var Set = edu_stanford_cs_sjslib_util.Set;", "var Stack = edu_stanford_cs_sjslib_util.Stack;"};/**
 * Implements `defineClasses(SVM svm)` returning `void`. Non-trivial control flow (≈10 LOC, complexity score 0).
 */


   public void defineClasses(SVM svm) {
      this.defineClass(svm, "ActionEvent", new SJSActionEventClass());
      this.defineClass(svm, "ArrayList", new SJSArrayListClass());
      this.defineClass(svm, "Grid", new SJSGridClass());
      this.defineClass(svm, "Map", new SJSMapClass());
      this.defineClass(svm, "Queue", new SJSQueueClass());
      this.defineClass(svm, "Random", new SJSRandomClass());
      this.defineClass(svm, "Set", new SJSSetClass());
      this.defineClass(svm, "Stack", new SJSStackClass());
   }

   public String[] getDependencies() {
      return this.DEPENDENCIES;
   }

   public String[] getWrapper() {
      return this.WRAPPER;
   }
}
