package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import java.util.ArrayDeque;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


class Queue extends ArrayDeque<Value> {
}
