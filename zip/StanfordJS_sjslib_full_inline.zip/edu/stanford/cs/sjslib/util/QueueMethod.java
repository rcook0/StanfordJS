package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


abstract class QueueMethod extends SVMMethod {
   public Queue getQueue(SVM svm, Value receiver) {
      return receiver == null ? (Queue)svm.pop().getValue() : (Queue)receiver.getValue();
   }
}
