package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


class Queue_remove extends QueueMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. This method manipulates collection state (maps/lists). Non-trivial control flow (≈9 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Queue.remove", "");
      Queue queue = this.getQueue(svm, receiver);
      if (queue.isEmpty()) {
         throw new RuntimeException("Queue is empty");
      } else {
         svm.push((Value)queue.remove());
      }
   }
}
