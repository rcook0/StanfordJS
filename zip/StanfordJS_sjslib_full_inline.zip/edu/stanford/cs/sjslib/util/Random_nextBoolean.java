package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.random.RandomGenerator;
import edu.stanford.cs.svm.SVM;
import edu.stanford.cs.svm.SVMMethod;
/**
 * Component providing functionality within this library.
 */


class Random_nextBoolean extends SVMMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈11 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      if (svm.getArgumentCount() == 0) {
         svm.checkSignature("Random.nextBoolean", "");
         svm.pushBoolean(RandomGenerator.getInstance().nextBoolean());
      } else {
         svm.checkSignature("Random.nextDouble", "D");
         double p = svm.popDouble();
         svm.pushBoolean(RandomGenerator.getInstance().nextBoolean(p));
      }

   }
}
