package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSGridClass extends SVMClass {
   public SJSGridClass() {
      this.defineMethod("new", new Grid_new());
      this.defineMethod("numRows", new Grid_numRows());
      this.defineMethod("numCols", new Grid_numCols());
      this.defineMethod("resize", new Grid_resize());
      this.defineMethod("inBounds", new Grid_inBounds());
      this.defineMethod("get", new Grid_get());
      this.defineMethod("set", new Grid_set());
      this.defineMethod("toString", new Grid_toString());
   }
}
