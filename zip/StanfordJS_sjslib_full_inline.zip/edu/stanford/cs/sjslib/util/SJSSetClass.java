package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSSetClass extends SVMClass {
   public SJSSetClass() {
      this.defineMethod("new", new Set_new());
      this.defineMethod("keyArray", new Set_keyArray());
      this.defineMethod("size", new Set_size());
      this.defineMethod("isEmpty", new Set_isEmpty());
      this.defineMethod("clear", new Set_clear());
      this.defineMethod("contains", new Set_contains());
      this.defineMethod("add", new Set_add());
      this.defineMethod("remove", new Set_remove());
   }
}
