package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.svm.SVMClass;
/**
 * Component providing functionality within this library.
 */


public class SJSStackClass extends SVMClass {
   public SJSStackClass() {
      this.defineMethod("new", new Stack_new());
      this.defineMethod("size", new Stack_size());
      this.defineMethod("isEmpty", new Stack_isEmpty());
      this.defineMethod("clear", new Stack_clear());
      this.defineMethod("push", new Stack_push());
      this.defineMethod("pop", new Stack_pop());
      this.defineMethod("peek", new Stack_peek());
   }
}
