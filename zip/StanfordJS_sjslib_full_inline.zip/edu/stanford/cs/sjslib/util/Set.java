package edu.stanford.cs.sjslib.util;

import java.util.TreeSet;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


class Set extends TreeSet<String> {
}
