package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 * Uses collections to model flags, option tables, and parsed values.
 */


class Set_clear extends SetMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈5 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Set.clear", "");
      this.getSet(svm, receiver).clear();
      svm.push(Value.UNDEFINED);
   }
}
