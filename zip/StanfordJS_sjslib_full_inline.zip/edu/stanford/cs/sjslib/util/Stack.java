package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import java.util.ArrayDeque;
/**
 * Component providing functionality within this library.
 */


class Stack extends ArrayDeque<Value> {
}
