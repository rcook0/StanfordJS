package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Stack_pop extends StackMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈9 LOC, complexity score 1).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Stack.pop", "");
      Stack stack = this.getStack(svm, receiver);
      if (stack.isEmpty()) {
         throw new RuntimeException("Stack is empty");
      } else {
         svm.push((Value)stack.pop());
      }
   }
}
