package edu.stanford.cs.sjslib.util;

import edu.stanford.cs.exp.Value;
import edu.stanford.cs.svm.SVM;
/**
 * Component providing functionality within this library.
 */


class Stack_push extends StackMethod {/**
 * Implements `execute(SVM svm, Value receiver)` returning `void`. Non-trivial control flow (≈6 LOC, complexity score 0).
 */

   public void execute(SVM svm, Value receiver) {
      svm.checkSignature("Stack.push", "*");
      Value v = svm.pop();
      this.getStack(svm, receiver).push(v);
      svm.push(Value.UNDEFINED);
   }
}
