package edu.stanford.cs.utf8;

import java.io.UnsupportedEncodingException;
/**
 * UTF-8/Unicode helpers for encoding/decoding, code point handling, and validation.
 * Implements code point iteration and surrogate pair handling per Unicode rules.
 */


public class UTF8 {/**
 * Implements `encode(String str)` returning `int[]`. Non-trivial control flow (≈23 LOC, complexity score 3).
 */

   public static int[] encode(String str) {
      try {
         byte[] bytes = str.getBytes("UTF-8");
         int n = bytes.length;
         int w = (n + 4) / 4;
         int[] array = new int[w];
         int shift = 24;
         int offset = 0;/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


         for(int i = 0; i < n; ++i) {
            array[offset] |= (bytes[i] & 255) << shift;
            shift -= 8;/**
 * Implements `if(shift < 0)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

            if (shift < 0) {
               shift = 24;
               ++offset;
            }
         }

         return array;
      } catch (UnsupportedEncodingException var8) {
         throw new RuntimeException(var8.getMessage());
      }
   }

   public static String decode(int[] array) {
      return decode(array, 0);
   }/**
 * Implements `decode(int[] array, int offset)` returning `String`. Non-trivial control flow (≈20 LOC, complexity score 3).
 */


   public static String decode(int[] array, int offset) {
      int n = getByteLength(array, offset);
      byte[] bytes = new byte[n];
      int shift = 24;/**
 * Implements `for(int i = 0; i < n; ++i)` returning ``. Non-trivial control flow (≈8 LOC, complexity score 1).
 */


      for(int i = 0; i < n; ++i) {
         bytes[i] = (byte)(array[offset] >> shift & 255);
         shift -= 8;/**
 * Implements `if(shift < 0)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (shift < 0) {
            shift = 24;
            ++offset;
         }
      }

      try {
         return new String(bytes, "UTF-8");
      } catch (UnsupportedEncodingException var6) {
         throw new RuntimeException(var6.getMessage());
      }
   }/**
 * Implements `getByteLength(int[] array, int offset)` returning `int`. Non-trivial control flow (≈14 LOC, complexity score 1).
 */


   private static int getByteLength(int[] array, int offset) {
      int shift = 24;

      int i;
      for(i = 0; (array[offset] >> shift & 255) != 0; ++i) {
         shift -= 8;/**
 * Implements `if(shift < 0)` returning ``. Non-trivial control flow (≈4 LOC, complexity score 0).
 */

         if (shift < 0) {
            shift = 24;
            ++offset;
         }
      }

      return i;
   }
}
